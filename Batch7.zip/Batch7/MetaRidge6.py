#!/usr/bin/env python3
# MetaRidge5.py
# RidgeCV meta-learner with GroupKFold by isotope,
# energy/nucleus-aware features, per-base repeats & variance penalty.

from __future__ import annotations
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_error, r2_score

from NN6  import predict_nn
from GBRT import predict_xgb
from RF6  import predict_rf

# ───────────────────────── helpers ─────────────────────────
def _energy_fraction(df: pd.DataFrame) -> np.ndarray:
    by_iso = df.groupby(["Z", "A"])["ENG"]
    return (df["ENG"] - by_iso.transform("min")) / (by_iso.transform("max") - by_iso.transform("min"))

def _make_features(
    df: pd.DataFrame,
    *,
    include_ZA: bool,
    include_ENG: bool,
    eng_poly: int,
    add_interactions: bool = True,
) -> pd.DataFrame:
    f  = df["f"].values
    nn = df["nn_pred"].values
    xg = df["xgb_pred"].values
    rf = df["rf_pred"].values

    X = pd.DataFrame({
        "nn":   nn, "xgb": xg, "rf": rf,
        "nn_f": nn * f, "xgb_f": xg * f, "rf_f": rf * f,
        "f": f,
    })

    if include_ENG:
        eng = df["ENG"].values
        X["ENG"] = eng
        if eng_poly >= 2:
            eng2 = eng * eng
            X["ENG2"] = eng2
        if eng_poly >= 3:
            X["ENG3"] = eng * eng * eng
        if add_interactions:
            X["nn_eng"]  = nn * eng
            X["xgb_eng"] = xg * eng
            X["rf_eng"]  = rf * eng
            if eng_poly >= 2:
                X["nn_eng2"]  = nn * eng2
                X["xgb_eng2"] = xg * eng2
                X["rf_eng2"]  = rf * eng2

    if include_ZA:
        Z = df["Z"].values; A = df["A"].values
        X["Z"] = Z; X["A"] = A
        if add_interactions:
            X["nn_Z"]  = nn * Z;   X["xgb_Z"] = xg * Z;   X["rf_Z"]  = rf * Z
            X["nn_A"]  = nn * A;   X["xgb_A"] = xg * A;   X["rf_A"]  = rf * A

    if add_interactions:
        X["nn_xgb"] = nn * xg
        X["nn_rf"]  = nn * rf
        X["xgb_rf"] = xg * rf
        X["nn2"]    = nn * nn
        X["xgb2"]   = xg * xg
        X["rf2"]    = rf * rf

    return X

# ───────────────────────── main API ─────────────────────────
def meta_ridge6_gkf_stack(
    train_csv: str | Path,
    target_csv: str | Path,
    *,
    k_folds: int = 5,
    label_col: str = "XS",
    include_ZA: bool = True,
    include_ENG: bool = True,
    eng_poly: int = 1,
    use_log: bool = False,
    balance_groups: bool = False,
    base_repeats: int = 15,
    penalize_variance: bool = True,
    verbose: bool = False,
    plot: bool = False,
) -> pd.DataFrame:
    """
    base_repeats: repeat each base model this many times per fold & average preds
    penalize_variance: downweight high-variance samples via sample_weight
    """
    train_csv  = Path(train_csv).resolve()
    target_csv = Path(target_csv).resolve()

    # 1) OOF meta-train
    train_df = pd.read_csv(train_csv).reset_index(drop=True)
    groups   = train_df["Z"].astype(str) + "_" + train_df["A"].astype(str)
    gkf      = GroupKFold(n_splits=k_folds)
    oof_chunks: list[pd.DataFrame] = []

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        for fold, (tr_idx, va_idx) in enumerate(gkf.split(train_df, groups=groups), start=1):
            tr_df = train_df.iloc[tr_idx]
            va_df = train_df.iloc[va_idx].reset_index(drop=True)

            tr_path = tmp/f"train_{fold}.csv"
            va_path = tmp/f"valid_{fold}.csv"
            tr_df.to_csv(tr_path, index=False)
            va_df.to_csv(va_path, index=False)

            def _repeat_and_agg(fn):
                """Returns (mean_preds, var_preds) arrays of length n_rows."""
                preds = []
                for _ in range(base_repeats):
                    dfp = fn(tr_path, va_path)
                    preds.append(dfp[f"{fn.__name__.split('_')[-1]}_pred"].to_numpy())
                arr = np.stack(preds, axis=1)
                return arr.mean(axis=1), arr.var(axis=1)

            nn_mean, nn_var   = _repeat_and_agg(predict_nn)
            xgb_mean, xgb_var = _repeat_and_agg(predict_xgb)
            rf_mean,  rf_var  = _repeat_and_agg(predict_rf)

            va = va_df[["ERG","Z","A"]].rename(columns={"ERG":"ENG"}).copy()
            if label_col in va_df:
                va["actual"] = va_df[label_col].values

            va["nn_pred"],   va["var_nn"]   = nn_mean,   nn_var
            va["xgb_pred"],  va["var_xgb"]  = xgb_mean,  xgb_var
            va["rf_pred"],   va["var_rf"]   = rf_mean,   rf_var
            va["f"]        = _energy_fraction(va)

            oof_chunks.append(va)

    meta_train = pd.concat(oof_chunks, ignore_index=True)
    if use_log:
        y_tr = np.log1p(meta_train["actual"].astype(float))
    else:
        y_tr = meta_train["actual"].astype(float)

    X_tr = _make_features(
        meta_train,
        include_ZA=include_ZA,
        include_ENG=include_ENG,
        eng_poly=eng_poly,
        add_interactions=True,
    )

    # build sample_weight from variance if requested
    fit_kwargs = {}
    if penalize_variance:
        # combine per-base variances into a single penalty (you can adjust weights here)
        total_var = meta_train["var_nn"] + meta_train["var_xgb"] + meta_train["var_rf"]
        sw = 1.0/(1.0 + total_var)  # samples with large variance down-weighted
        fit_kwargs["ridge__sample_weight"] = sw.values

    if balance_groups:
        grp = meta_train["Z"].astype(str)+"_"+meta_train["A"].astype(str)
        counts = grp.value_counts()
        wgrp = grp.map(lambda g: 1.0/counts[g]).astype(float)
        fit_kwargs.setdefault("ridge__sample_weight", wgrp.values)

    # 2) fit meta
    alphas = np.logspace(-3, 2, 25)
    meta_model = Pipeline([
        ("scaler", StandardScaler()), 
        ("ridge", RidgeCV(alphas=alphas))
    ])
    meta_model.fit(X_tr, y_tr, **fit_kwargs)

    if verbose:
        p_tr = meta_model.predict(X_tr)
        if use_log:
            p_tr = np.expm1(p_tr); y_ev = np.expm1(y_tr)
        else:
            y_ev = y_tr
        print(f"[OOF TRAIN] MSE={mean_squared_error(y_ev,p_tr):.6f}  R2={r2_score(y_ev,p_tr):.4f}")

    # 3) final TARGET predict (average bases, no var tracking)
    td = pd.read_csv(target_csv).reset_index(drop=True)
    base = td[["ERG","Z","A"]].rename(columns={"ERG":"ENG"}).copy()
    def _rep_final(fn):
        preds = []
        for _ in range(base_repeats):
            preds.append(fn(train_csv, target_csv)[f"{fn.__name__.split('_')[-1]}_pred"].to_numpy())
        arr = np.stack(preds, axis=1)
        return arr.mean(axis=1)

    base["nn_pred"]  = _rep_final(predict_nn)
    base["xgb_pred"] = _rep_final(predict_xgb)
    base["rf_pred"]  = _rep_final(predict_rf)
    base["f"]        = _energy_fraction(base)
    if label_col in td:
        base["actual"] = td[label_col].values

    X_te = _make_features(
        base,
        include_ZA=include_ZA,
        include_ENG=include_ENG,
        eng_poly=eng_poly,
        add_interactions=True,
    )
    p_te = meta_model.predict(X_te)
    if use_log:
        p_te = np.expm1(p_te)
    base["stack_pred"] = p_te

    # optional envelope clipping (unchanged)
    lo = base[["nn_pred","xgb_pred","rf_pred"]].min(axis=1)
    hi = base[["nn_pred","xgb_pred","rf_pred"]].max(axis=1)
    base["stack_pred"] = np.clip(base["stack_pred"], lo, hi)

    if verbose and "actual" in base:
        print(f"[FINAL TEST] MSE={mean_squared_error(base.actual,base.stack_pred):.6f}"
              f"  R2={r2_score(base.actual,base.stack_pred):.4f}")

    if plot:
        plt.figure(figsize=(8,5))
        plt.scatter(base.ENG, base.actual,   label="Actual", marker="o", alpha=.6)
        plt.scatter(base.ENG, base.nn_pred,  label="NN",     marker="x")
        plt.scatter(base.ENG, base.xgb_pred, label="XGB",    marker="+")
        plt.scatter(base.ENG, base.rf_pred,  label="RF",     marker="^")
        plt.scatter(base.ENG, base.stack_pred,label="Meta",   marker="*")
        plt.legend(); plt.tight_layout()
        plt.savefig(target_csv.stem + "_meta5.png", dpi=200)
        plt.close()

    return base

# if you want a quick CLI test, you can add the usual __main__ guard here
