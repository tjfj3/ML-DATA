#!/usr/bin/env python3
# meta_ridge_gkf.py
# RidgeCV meta-learner trained with GroupKFold by isotope, energy-aware features,
# and safe alignment-by-position (no merges on ENG for predictions).

from __future__ import annotations
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_error, r2_score

# Base helpers must be importable (same folder or on PYTHONPATH)
from NN6  import predict_nn
from GBRT import predict_xgb
from RF6  import predict_rf

# ───────────────────────── helpers ─────────────────────────
def _energy_fraction(df: pd.DataFrame) -> np.ndarray:
    """Normalise ENG to [0,1] within each isotope (Z,A)."""
    by_iso = df.groupby(["Z", "A"])["ENG"]
    return (df["ENG"] - by_iso.transform("min")) / (by_iso.transform("max") - by_iso.transform("min"))

def _make_features(df: pd.DataFrame, include_ZA: bool) -> pd.DataFrame:
    """Energy-aware meta features: base preds + gating by f (+ optional Z/A)."""
    f = df["f"].values
    X = pd.DataFrame({
        "nn":     df["nn_pred"].values,
        "xgb":    df["xgb_pred"].values,
        "rf":     df["rf_pred"].values,
        "nn_f":   df["nn_pred"].values  * f,
        "xgb_f":  df["xgb_pred"].values * f,
        "rf_f":   df["rf_pred"].values  * f,
        "f":      f,
    })
    if include_ZA:
        X["Z"] = df["Z"].values
        X["A"] = df["A"].values
    return X

# ───────────────────────── main API ─────────────────────────
def meta_ridge_gkf_stack(
    train_csv: str | Path,
    target_csv: str | Path,
    *,
    k_folds: int = 5,
    label_col: str = "XS",
    include_ZA: bool = False,
    verbose: bool = False,
    plot: bool = False,
) -> pd.DataFrame:
    """
    Train a RidgeCV meta-learner using GroupKFold by isotope (Z,A) on TRAIN,
    then predict TARGET. Predictions are aligned by row order (position),
    not by merging on ENG.

    Returns DataFrame with columns:
      ENG, Z, A, actual (if available), nn_pred, xgb_pred, rf_pred, f, stack_pred
    """
    train_csv  = Path(train_csv).resolve()
    target_csv = Path(target_csv).resolve()

    # 1) Build OOF meta-train on TRAIN (leakage-free) using GroupKFold by isotope
    train_df = pd.read_csv(train_csv).reset_index(drop=True)
    groups = train_df["Z"].astype(str) + "_" + train_df["A"].astype(str)
    gkf = GroupKFold(n_splits=k_folds)

    oof_chunks: list[pd.DataFrame] = []
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        for fold, (tr_idx, va_idx) in enumerate(gkf.split(train_df, groups=groups), start=1):
            tr_df = train_df.iloc[tr_idx].copy()
            va_df = train_df.iloc[va_idx].copy().reset_index(drop=True)

            tr_path = tmpdir / f"train_fold{fold}.csv"
            va_path = tmpdir / f"valid_fold{fold}.csv"
            tr_df.to_csv(tr_path, index=False)
            va_df.to_csv(va_path, index=False)

            # base predictions for validation slice, trained on tr_path
            df_nn  = predict_nn (tr_path, va_path)
            df_xgb = predict_xgb(tr_path, va_path)
            df_rf  = predict_rf (tr_path, va_path)

            # Safe alignment-by-position (avoid ENG float merge pitfalls)
            va_merge = va_df[["ERG", "Z", "A"]].rename(columns={"ERG": "ENG"}).copy()
            if label_col in va_df.columns:
                va_merge["actual"] = va_df[label_col].values

            # attach predictions by position
            va_merge["nn_pred"]  = df_nn["nn_pred"].values
            va_merge["xgb_pred"] = df_xgb["xgb_pred"].values
            va_merge["rf_pred"]  = df_rf["rf_pred"].values
            va_merge["f"]        = _energy_fraction(va_merge)
            oof_chunks.append(va_merge)

    meta_train = pd.concat(oof_chunks, axis=0, ignore_index=True)
    X_tr = _make_features(meta_train, include_ZA=include_ZA)
    y_tr = meta_train["actual"].astype(float).values

    meta_model = Pipeline([
        ("scaler", StandardScaler(with_mean=True, with_std=True)),
        ("ridge",  RidgeCV(alphas=np.logspace(-6, 3, 30)))
    ]).fit(X_tr, y_tr)

    if verbose and "actual" in meta_train:
        pred_tr = meta_model.predict(X_tr)
        mse_tr  = mean_squared_error(y_tr, pred_tr)
        r2_tr   = r2_score(y_tr, pred_tr)
        print(f"[TRAIN OOF-fit] RidgeCV  folds={k_folds}  MSE={mse_tr:.6f}  R²={r2_tr:.6f}")

    # 2) Final TARGET predictions (no target labels used for fitting)
    target_df = pd.read_csv(target_csv).reset_index(drop=True)
    te = target_df[["ERG", "Z", "A"]].rename(columns={"ERG": "ENG"}).copy()

    if label_col in target_df.columns:
        te["actual"] = target_df[label_col].values

    df_nn_te  = predict_nn (train_csv, target_csv)
    df_xgb_te = predict_xgb(train_csv, target_csv)
    df_rf_te  = predict_rf (train_csv, target_csv)

    te["nn_pred"]  = df_nn_te["nn_pred"].values
    te["xgb_pred"] = df_xgb_te["xgb_pred"].values
    te["rf_pred"]  = df_rf_te["rf_pred"].values
    te["f"]        = _energy_fraction(te)

    X_te = _make_features(te, include_ZA=include_ZA)
    te["stack_pred"] = meta_model.predict(X_te)

    # Optional diagnostics & plot
    if verbose and "actual" in te and te["actual"].notna().any():
        mse = mean_squared_error(te["actual"], te["stack_pred"])
        r2  = r2_score       (te["actual"], te["stack_pred"])
        print(f"[TARGET] RidgeCV  MSE={mse:.6f}  R²={r2:.6f}")

    if plot:
        out_png = target_csv.with_suffix("").name + "_RidgeGKF.png"
        plt.figure(figsize=(8,5))
        if "actual" in te:
            plt.scatter(te["ENG"], te["actual"], label="Actual", marker="o", alpha=.8)
        plt.scatter(te["ENG"], te["nn_pred"],    label="NN",  marker="x")
        plt.scatter(te["ENG"], te["xgb_pred"],   label="XGB", marker="+")
        plt.scatter(te["ENG"], te["rf_pred"],    label="RF",  marker="^")
        plt.scatter(te["ENG"], te["stack_pred"], label="Meta (Ridge+GKF)", marker="*", s=70, c="black")
        plt.xlabel("Energy (MeV)"); plt.ylabel("Cross Section (XS)")
        plt.title("Ridge meta on TARGET (OOF fit, GroupKFold by isotope)")
        plt.legend(); plt.tight_layout(); plt.savefig(out_png, dpi=200)

    return te

# Optional CLI for a quick local run
if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("train_csv")
    p.add_argument("target_csv")
    p.add_argument("--folds", type=int, default=5)
    p.add_argument("--label-col", default="XS")
    p.add_argument("--include-ZA", action="store_true")
    p.add_argument("--plot", action="store_true")
    a = p.parse_args()
    meta_ridge_gkf_stack(a.train_csv, a.target_csv,
                         k_folds=a.folds, label_col=a.label_col,
                         include_ZA=a.include_ZA, verbose=True, plot=a.plot)
