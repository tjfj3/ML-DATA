#!/usr/bin/env python3
# meta_linbin.py
# OOF-trained linear-bin meta stacker (no absolute paths; drop-in API)

from __future__ import annotations
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, r2_score

# Base helpers must be importable (same folder or on PYTHONPATH)
from NN6  import predict_nn
from GBRT import predict_xgb
from RF6  import predict_rf

# ───────────────────────── helpers ─────────────────────────
def _energy_fraction(df: pd.DataFrame) -> np.ndarray:
    """Normalise ENG to [0,1] within each isotope (Z,A)."""
    by_iso = df.groupby(["Z", "A"])["ENG"]
    return (df["ENG"] - by_iso.transform("min")) / (by_iso.transform("max") - by_iso.transform("min"))

def _best_ws(y, nn, xgb, rf, *, step: float):
    """Best convex weights (w_nn, w_xgb, w_rf) via simplex grid search."""
    y, nn, xgb, rf = map(lambda z: np.asarray(z, dtype=float), (y, nn, xgb, rf))
    if y.size == 0:
        return (1/3, 1/3, 1/3)
    grid = np.arange(0.0, 1.0 + 1e-9, step)
    best_mse, best_w = np.inf, (1/3, 1/3, 1/3)
    for w_nn in grid:
        for w_xgb in grid:
            s = w_nn + w_xgb
            if s > 1.0:
                break
            w_rf = 1.0 - s
            mse = ((w_nn*nn + w_xgb*xgb + w_rf*rf - y) ** 2).mean()
            if mse < best_mse:
                best_mse, best_w = mse, (w_nn, w_xgb, w_rf)
    return best_w

def _merge_iso(df_pred: pd.DataFrame, csv_path: str | Path) -> pd.DataFrame:
    iso = pd.read_csv(csv_path)[["ERG","Z","A"]].rename(columns={"ERG":"ENG"})
    return df_pred.merge(iso, on="ENG")

# ───────────────────────── main API ─────────────────────────
def meta_linbin_stack(
    train_csv: str | Path,
    target_csv: str | Path,
    *,
    bins: int = 10,
    step: float = 0.05,
    k_folds: int = 5,
    verbose: bool = False,
    plot: bool = False,
) -> pd.DataFrame:
    """
    Learn per-energy-bin convex weights (w_nn, w_xgb, w_rf) on TRAIN via OOF
    predictions, then apply those weights to TARGET.

    Returns a DataFrame with columns:
      ENG, Z, A, actual, nn_pred, xgb_pred, rf_pred, f, bin, stack_pred
    """
    train_csv  = Path(train_csv).resolve()
    target_csv = Path(target_csv).resolve()

    # 1) OOF meta-train on TRAIN (no leakage)
    train_full = pd.read_csv(train_csv)
    idx = np.arange(len(train_full))
    kf = KFold(n_splits=k_folds, shuffle=True, random_state=42)

    oof_frames = []
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        for fold, (tr_idx, va_idx) in enumerate(kf.split(idx), start=1):
            tr_df = train_full.iloc[tr_idx].copy()
            va_df = train_full.iloc[va_idx].copy()

            tr_path = tmpdir / f"train_fold{fold}.csv"
            va_path = tmpdir / f"valid_fold{fold}.csv"
            tr_df.to_csv(tr_path, index=False)
            va_df.to_csv(va_path, index=False)

            df_nn  = predict_nn (tr_path, va_path)
            df_xgb = predict_xgb(tr_path, va_path)
            df_rf  = predict_rf (tr_path, va_path)

            va = (_merge_iso(df_nn, va_path)[["ENG","Z","A","actual","nn_pred"]]
                  .merge(df_xgb[["ENG","xgb_pred"]], on="ENG")
                  .merge(df_rf[["ENG","rf_pred"]],   on="ENG")
                  .sort_values(["Z","A","ENG"], kind="mergesort")
                  .reset_index(drop=True))
            oof_frames.append(va)

    meta_train = pd.concat(oof_frames, axis=0, ignore_index=True)
    meta_train["f"]   = _energy_fraction(meta_train)
    meta_train["bin"] = pd.cut(meta_train["f"], bins=bins, labels=False, include_lowest=True)

    # Learn per-bin weights on TRAIN
    w_per_bin = {
        k: _best_ws(
            meta_train.actual[meta_train.bin == k],
            meta_train.nn_pred[meta_train.bin == k],
            meta_train.xgb_pred[meta_train.bin == k],
            meta_train.rf_pred[meta_train.bin == k],
            step=step,
        )
        for k in range(bins)
    }

    # Optional OOF diagnostics
    if verbose:
        oof_stack = []
        for b, nn, gx, rf in zip(meta_train.bin, meta_train.nn_pred, meta_train.xgb_pred, meta_train.rf_pred):
            if pd.isna(b):
                oof_stack.append((nn + gx + rf) / 3.0)
            else:
                w_nn, w_xgb, w_rf = w_per_bin.get(int(b), (1/3,1/3,1/3))
                oof_stack.append(w_nn*nn + w_xgb*gx + w_rf*rf)
        mse_tr = mean_squared_error(meta_train.actual, oof_stack)
        r2_tr  = r2_score(meta_train.actual, oof_stack)
        print(f"[TRAIN OOF] LinBin weights  bins={bins} step={step}  MSE={mse_tr:.6f}  R²={r2_tr:.6f}")

    # 2) Apply to TARGET
    df_nn_te  = predict_nn (train_csv, target_csv)
    df_xgb_te = predict_xgb(train_csv, target_csv)
    df_rf_te  = predict_rf (train_csv, target_csv)

    target = (_merge_iso(df_nn_te, target_csv)[["ENG","Z","A","actual","nn_pred"]]
              .merge(df_xgb_te[["ENG","xgb_pred"]], on="ENG")
              .merge(df_rf_te[["ENG","rf_pred"]],   on="ENG")
              .sort_values(["Z","A","ENG"], kind="mergesort")
              .reset_index(drop=True))
    target["f"]   = _energy_fraction(target)
    target["bin"] = pd.cut(target["f"], bins=bins, labels=False, include_lowest=True)

    stack_preds = []
    for b, nn, gx, rf in zip(target.bin, target.nn_pred, target.xgb_pred, target.rf_pred):
        if pd.isna(b):
            stack_preds.append((nn + gx + rf) / 3.0)
        else:
            w_nn, w_xgb, w_rf = w_per_bin.get(int(b), (1/3,1/3,1/3))
            stack_preds.append(w_nn*nn + w_xgb*gx + w_rf*rf)
    target["stack_pred"] = stack_preds

    # Optional plotting
    if plot:
        out_png = target_csv.with_suffix("").name + f"_LinBinMeta.png"
        plt.figure(figsize=(8,5))
        plt.scatter(target["ENG"], target["actual"],     label="Actual", marker="o", alpha=.8)
        plt.scatter(target["ENG"], target["nn_pred"],    label="NN",     marker="x")
        plt.scatter(target["ENG"], target["xgb_pred"],   label="XGB",    marker="+")
        plt.scatter(target["ENG"], target["rf_pred"],    label="RF",     marker="^")
        plt.scatter(target["ENG"], target["stack_pred"], label="LinBinMeta (OOF weights)", marker="*", s=70, c="black")
        plt.xlabel("Energy (MeV)"); plt.ylabel("Cross Section (XS)")
        plt.title(f"LinBin OOF weights → applied to TARGET (bins={bins}, step={step})")
        plt.legend(); plt.tight_layout(); plt.savefig(out_png, dpi=200)

    return target

# ─────────────── Stand-alone CLI (optional sanity run) ───────────────
if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("train_csv")
    p.add_argument("target_csv")
    p.add_argument("--bins",  type=int,   default=10)
    p.add_argument("--step",  type=float, default=0.05)
    p.add_argument("--folds", type=int,   default=5)
    p.add_argument("--plot",  action="store_true")
    args = p.parse_args()
    meta_linbin_stack(args.train_csv, args.target_csv,
                      bins=args.bins, step=args.step, k_folds=args.folds,
                      verbose=True, plot=args.plot)
