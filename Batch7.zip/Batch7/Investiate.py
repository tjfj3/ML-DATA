#!/usr/bin/env python3
"""
Hard-coded single-isotope comparator (Z=18, A=41) — CSV-only artifacts
======================================================================

Exactly like Investiate.py but avoids the optional Parquet dependency by
*always* writing CSV (rows.csv). No CLI args.

Run:  srun python Investiate_v2.py
"""
from __future__ import annotations

import json
import os
import random
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, r2_score

# --- base & meta imports ---
from NN6 import predict_nn
from RF6 import predict_rf
from GBRT import predict_xgb
from MetaRidge3 import meta_ridge_gkf_stack as meta3
from MetaRidge4 import meta_ridge4_gkf_stack as meta4

# ---------------------------
# Hard-coded configuration
# ---------------------------
CONFIG = {
    "CSV_PATH": "../Batch5/AllClean4_S.csv",  # change if needed
    "Z": 18,
    "A": 41,
    "META_IDS": [3, 4],
    "KFOLDS": 5,
    "REPEATS": 3,
    "LABEL": "XS",
    "INCLUDE_ZA": True,
    "INCLUDE_ENG": True,
    "ENG_POLY": 1,
    "USE_LOG": False,
    "BALANCE_GROUPS": False,
    # Ridge4-only knobs
    "ALPHA_MIN": 1e-6,
    "ALPHA_MAX": 1e3,
    "ALPHA_NUM": 30,
    "CLIP_ENVELOPE": True,
    # Output & seeds
    "OUT_DIR": "./diag_runs",
    "BASE_SEED": 12345,
}

# ---------------------------
# Utilities
# ---------------------------

def set_all_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.use_deterministic_algorithms(True)
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    except Exception:
        pass
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
        os.environ["TF_DETERMINISTIC_OPS"] = "1"
    except Exception:
        pass


def now_ts() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def resolve_csv(primary: str) -> Path:
    cand = [primary, "../Batch6/feature_elim_outputs/AllClean4_S.csv"]
    for p in cand:
        if Path(p).expanduser().exists():
            return Path(p).resolve()
    raise FileNotFoundError(
        f"CSV not found. Update CONFIG['CSV_PATH'] (tried: {cand}).")

# ---------------------------
# Core pipeline
# ---------------------------

def build_train_target(csv_path: Path, z: int, a: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
    full = pd.read_csv(csv_path)
    df_test  = full[(full.Z == z) & (full.A == a)].copy()
    df_train = full.drop(df_test.index).drop(columns=["XSlow", "XSupp"], errors="ignore")
    return df_train.reset_index(drop=True), df_test.reset_index(drop=True)


def call_meta(meta_id: int,
              train_csv: Path, target_csv: Path,
              *, k_folds: int, label_col: str,
              include_ZA: bool, include_ENG: bool, eng_poly: int,
              use_log: bool, balance_groups: bool,
              alpha_min: float, alpha_max: float, alpha_num: int,
              clip_envelope: bool) -> pd.DataFrame:
    if meta_id == 3:
        return meta3(train_csv, target_csv,
                     k_folds=k_folds, label_col=label_col,
                     include_ZA=include_ZA, include_ENG=include_ENG, eng_poly=eng_poly,
                     use_log=use_log, balance_groups=balance_groups,
                     verbose=False, plot=False)
    if meta_id == 4:
        return meta4(train_csv, target_csv,
                     k_folds=k_folds, label_col=label_col,
                     include_ZA=include_ZA, include_ENG=include_ENG, eng_poly=eng_poly,
                     use_log=use_log, balance_groups=balance_groups,
                     verbose=False, plot=False,
                     alpha_min=alpha_min, alpha_max=alpha_max, alpha_num=alpha_num,
                     clip_envelope=clip_envelope)
    raise ValueError(f"Unsupported meta id: {meta_id}")


def sort_by_eng(df: pd.DataFrame) -> pd.DataFrame:
    cols = [c for c in ["ENG", "Z", "A", "actual", "nn_pred", "xgb_pred", "rf_pred", "stack_pred"] if c in df.columns]
    return df.sort_values(["ENG"], kind="mergesort").reset_index(drop=True)[cols]


def run_once(meta_id: int, outdir: Path, train_df: pd.DataFrame, test_df: pd.DataFrame,
             *, k_folds: int, label_col: str,
             include_ZA: bool, include_ENG: bool, eng_poly: int,
             use_log: bool, balance_groups: bool,
             alpha_min: float, alpha_max: float, alpha_num: int,
             clip_envelope: bool, seed: int) -> Dict:
    set_all_seeds(seed)

    tmp = outdir / f"tmp_meta{meta_id}_{seed}"
    tmp.mkdir(parents=True, exist_ok=True)
    tr_csv, te_csv = tmp / "train.csv", tmp / "target.csv"
    train_df.to_csv(tr_csv, index=False)
    test_df.to_csv(te_csv, index=False)

    te = call_meta(meta_id, tr_csv, te_csv,
                   k_folds=k_folds, label_col=label_col,
                   include_ZA=include_ZA, include_ENG=include_ENG, eng_poly=eng_poly,
                   use_log=use_log, balance_groups=balance_groups,
                   alpha_min=alpha_min, alpha_max=alpha_max, alpha_num=alpha_num,
                   clip_envelope=clip_envelope)

    te = sort_by_eng(te)

    y = te["actual"].to_numpy() if "actual" in te.columns else None
    nn = te["nn_pred"].to_numpy()
    xg = te["xgb_pred"].to_numpy()
    rf = te["rf_pred"].to_numpy()
    st = te["stack_pred"].to_numpy()

    def _m(s):
        return float(mean_squared_error(y, s)) if y is not None else float("nan")

    def _r(s):
        return float(r2_score(y, s)) if y is not None else float("nan")

    metrics = {
        "mse_nn": _m(nn), "mse_xgb": _m(xg), "mse_rf": _m(rf), "mse_meta": _m(st),
        "r2_nn": _r(nn),  "r2_xgb": _r(xg),  "r2_rf": _r(rf),  "r2_meta": _r(st),
        "n_rows": int(len(te))
    }

    arr_dir = outdir / "arrays"
    arr_dir.mkdir(parents=True, exist_ok=True)
    np.save(arr_dir / "nn_pred.npy", nn)
    np.save(arr_dir / "xgb_pred.npy", xg)
    np.save(arr_dir / "rf_pred.npy", rf)
    np.save(arr_dir / "meta.npy",     st)

    # Always write CSV to avoid optional parquet engine
    rows_csv = outdir / "rows.csv"
    te.to_csv(rows_csv, index=False)

    return {"meta_id": meta_id, "metrics": metrics, "rows_path": str(rows_csv)}


def compare_base_preds(run_dirs: Dict[int, Path], summary: Dict) -> None:
    mids = sorted(run_dirs.keys())
    for i in range(len(mids)):
        for j in range(i+1, len(mids)):
            m1, m2 = mids[i], mids[j]
            ddir = run_dirs[m1].parent / f"diffs_vs_{m2}"
            ddir.mkdir(parents=True, exist_ok=True)
            diffs = {}
            for name in ["nn_pred", "xgb_pred", "rf_pred", "meta"]:
                a = np.load(run_dirs[m1] / "arrays" / (name + ".npy"))
                b = np.load(run_dirs[m2] / "arrays" / (name + ".npy"))
                d = np.abs(a - b)
                diffs[name] = {"max_abs": float(np.max(d)), "mean_abs": float(np.mean(d)), "n": int(d.size)}
            with open(ddir / "summary.json", "w") as f:
                json.dump(diffs, f, indent=2)
            summary.setdefault("pairwise_diffs", {})[f"{m1}_vs_{m2}"] = diffs


# ---------------------------
# Main (no CLI)
# ---------------------------

def main() -> None:
    cfg = CONFIG.copy()
    csv_path = resolve_csv(cfg["CSV_PATH"])
    out_root = Path(cfg["OUT_DIR"]).resolve() / now_ts()
    out_root.mkdir(parents=True, exist_ok=True)

    with open(out_root / "console.txt", "w") as f:
        f.write(json.dumps(cfg | {"CSV_RESOLVED": str(csv_path)}, indent=2) + "\n")

    print("[RUN] leave-one-isotope-out for (Z,A)=(%d,%d) on %s" % (cfg["Z"], cfg["A"], csv_path))
    print("[RUN] meta ids:", cfg["META_IDS"]) 

    train_df, test_df = build_train_target(csv_path, cfg["Z"], cfg["A"])

    first_rep_dirs: Dict[int, Path] = {}
    summary = {"by_meta": {}, "cfg": cfg}

    for mid in cfg["META_IDS"]:
        mid_root = out_root / f"meta{mid}"
        mid_root.mkdir(parents=True, exist_ok=True)
        first_rep_dirs[mid] = mid_root / "rep_0"

        metrics_list: List[Dict] = []
        for r in range(cfg["REPEATS"]):
            seed = int(cfg["BASE_SEED"]) + r
            rdir = mid_root / f"rep_{r}"
            rdir.mkdir(parents=True, exist_ok=True)

            res = run_once(mid, rdir, train_df, test_df,
                           k_folds=cfg["KFOLDS"], label_col=cfg["LABEL"],
                           include_ZA=cfg["INCLUDE_ZA"], include_ENG=cfg["INCLUDE_ENG"], eng_poly=cfg["ENG_POLY"],
                           use_log=cfg["USE_LOG"], balance_groups=cfg["BALANCE_GROUPS"],
                           alpha_min=cfg["ALPHA_MIN"], alpha_max=cfg["ALPHA_MAX"], alpha_num=cfg["ALPHA_NUM"],
                           clip_envelope=cfg["CLIP_ENVELOPE"], seed=seed)
            metrics_list.append(res["metrics"])

        def agg(key: str) -> float:
            vals = [m[key] for m in metrics_list if not np.isnan(m[key])]
            return float(np.mean(vals)) if vals else float("nan")

        summary["by_meta"][str(mid)] = {
            "avg_mse_nn":   agg("mse_nn"),
            "avg_mse_xgb":  agg("mse_xgb"),
            "avg_mse_rf":   agg("mse_rf"),
            "avg_mse_meta": agg("mse_meta"),
            "avg_r2_nn":    agg("r2_nn"),
            "avg_r2_xgb":   agg("r2_xgb"),
            "avg_r2_rf":    agg("r2_rf"),
            "avg_r2_meta":  agg("r2_meta"),
            "n_rows":       metrics_list[0]["n_rows"] if metrics_list else 0,
            "repeats":      cfg["REPEATS"],
        }

    compare_base_preds(first_rep_dirs, summary)

    with open(out_root / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    for mid, stats in summary["by_meta"].items():
        print(f"[META {mid}] mse_nn={stats['avg_mse_nn']:.6g}  mse_xgb={stats['avg_mse_xgb']:.6g}  "
              f"mse_rf={stats['avg_mse_rf']:.6g}  mse_meta={stats['avg_mse_meta']:.6g}")
    print("[DONE] saved to:", out_root)


if __name__ == "__main__":
    main()
