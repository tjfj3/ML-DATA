#!/usr/bin/env python3
"""
make_full_mse_plot.py
─────────────────────
Merge S/M/L slice results, plot log-MSE vs A, and tell you where the
stacked model is beaten by NN, XGB, or RF.

Outputs
-------
Data/Ridge1_benchmark_full.csv
IsoPlots/Ridge1_mse_per_iso_full.png
stack_worse_than.csv     (only those isotopes where Stack is worse)
"""

import os
import pathlib
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

here = pathlib.Path(".").resolve()

# Ensure output directory exists
os.makedirs("IsoPlots", exist_ok=True)

# ── 1. merge slice CSVs ─────────────────────────────────────────────
dfs = [pd.read_csv(here / f"Data/Ridge6_benchmark_iso_{lbl}.csv") for lbl in "SML"]
full = pd.concat(dfs, ignore_index=True).sort_values("A")
full.to_csv("Data/Ridge6_benchmark_full.csv", index=False)
print(f"[OK] merged → Data/Ridge6_benchmark_full.csv  ({len(full)} rows)\n")

# ── 2. log-MSE vs A plot (offset, jitter, alpha) ───────────────────
import os, numpy as np
os.makedirs("IsoPlots", exist_ok=True)

fig, ax = plt.subplots(figsize=(10,5))
rng = np.random.default_rng(7)        # reproducible
jitter = rng.normal(0, 0.15, size=len(full))  # small horizontal jitter

# bolder NN/XGB using filled markers
series = [
    ("mse_nn",   "Neural Network",  "X", -0.30, "C0", 1.4),  # filled X
    ("mse_xgb",  "XGBoost", "P", -0.10, "C1", 1.4),  # filled plus
    ("mse_rf",   "Random Forest",  "^",  0.10, "C2", 1.0),
    ("mse_meta", "Stacked Ensemble", "*",  0.30, "C3", 1.0),
]

for col, label, marker, dx, color, lw in series:
    ax.scatter(
        full["A"] + dx + jitter, full[col],
        s=36, marker=marker,
        facecolors=color, edgecolors=color,
        linewidths=lw, alpha=1.0, label=label, zorder=2
    )

ax.set_xlabel("Mass number A")
ax.set_ylabel("Log of MSE")
ax.set_yscale("log")
ax.grid(True, which="both", ls="--", alpha=0.3)
ax.set_axisbelow(True)
ax.set_title("Average MSE vs A for all Isotopes")
ax.legend(framealpha=0.9)
fig.tight_layout()
outpath = "IsoPlots/Ridge6_mse_per_iso_full.png"
fig.savefig(outpath, dpi=300)
print(f"[OK] plot saved → {outpath}\n")