#!/usr/bin/env python3
# iso_benchmark_ridgegkf.py – per-isotope benchmark using RidgeCV (GroupKFold)
from __future__ import annotations
import argparse, pathlib, shutil, tempfile, re
import numpy as np, pandas as pd
from sklearn.metrics import mean_squared_error, r2_score
from mpi4py import MPI

from NN6  import predict_nn
from GBRT import predict_xgb
from RF6  import predict_rf
from MetaRidge3 import meta_ridge_gkf_stack

# ── MPI init ───────────────────────────────────────────────────────────
comm, rank, size = MPI.COMM_WORLD, MPI.COMM_WORLD.Get_rank(), MPI.COMM_WORLD.Get_size()
if rank == 0:
    print(f"[MPI] iso_benchmark_ridgegkf running on {size} ranks", flush=True)

# ── CLI ────────────────────────────────────────────────────────────────
def _valid_group(tag: str) -> str:
    # Accept S/M/L or Ss/Ms/Ls, Sl/Ml/Ll, Sp/Mp/Lp
    tag = tag.strip()
    if re.fullmatch(r"[SML](?:[slp])?$", tag):
        return tag
    raise argparse.ArgumentTypeError("Use S, M, L or Ss/Ms/Ls, Sl/Ml/Ll, Sp/Mp/Lp")

def parse_cli():
    p = argparse.ArgumentParser(description="Benchmark RidgeCV meta (GroupKFold) on S/M/L isotope slices")
    p.add_argument("group", type=_valid_group, help="Selects AllClean4_<GROUP>.csv")
    p.add_argument("--repeats",  type=int,   default=15,   help="Repetitions per isotope")
    p.add_argument("--folds",    type=int,   default=5,   help="K-folds for OOF training")
    p.add_argument("--label-col", default="XS",           help="Label column name in CSV (default XS)")
    p.add_argument("--include-ZA", action="store_true",   help="Add Z/A as meta features")
    return p.parse_args()

# ── Rank-0 setup ───────────────────────────────────────────────────────
if rank == 0:
    args    = parse_cli()
    GROUP   = args.group
    REPEATS = args.repeats
    KFOLDS  = args.folds
    LABEL   = args.label_col
    INC_ZA  = args.include_ZA

    data_dir = pathlib.Path("../Batch5") if len(GROUP) == 1 \
               else pathlib.Path("../Batch6/feature_elim_outputs")
    csv_path = data_dir / f"AllClean4_{GROUP}.csv"
    out_path = pathlib.Path(f"Data/Ridge3_benchmark_iso_{GROUP}.csv")
else:
    csv_path = out_path = GROUP = REPEATS = KFOLDS = LABEL = INC_ZA = None

csv_path = comm.bcast(csv_path, root=0)
out_path = comm.bcast(out_path, root=0)
GROUP    = comm.bcast(GROUP,    root=0)
REPEATS  = comm.bcast(REPEATS,  root=0)
KFOLDS   = comm.bcast(KFOLDS,   root=0)
LABEL    = comm.bcast(LABEL,    root=0)
INC_ZA   = comm.bcast(INC_ZA,   root=0)

# ── Load & partition work ──────────────────────────────────────────────
full = pd.read_csv(csv_path)
iso_rows = full[["Z", "A"]].drop_duplicates().to_numpy()
tasks = [iso_rows[i] for i in range(rank, len(iso_rows), size)]

def evaluate_iso(z: int, a: int) -> dict:
    # leave-one-isotope-out split: train = everything except this isotope
    df_test  = full[(full.Z == z) & (full.A == a)].copy()
    df_train = full.drop(df_test.index).drop(columns=["XSlow", "XSupp"], errors="ignore")

    tmpdir = pathlib.Path(tempfile.mkdtemp(prefix=f"r{rank}_"))
    tr_csv, te_csv = tmpdir / "train.csv", tmpdir / "target.csv"
    df_train.to_csv(tr_csv, index=False)
    df_test.to_csv(te_csv,  index=False)

    mse_nn, mse_xgb, mse_rf, mse_meta = [], [], [], []
    r2_nn,  r2_xgb,  r2_rf,  r2_meta  = [], [], [], []

    for _ in range(REPEATS):
        res = meta_ridge_gkf_stack(tr_csv, te_csv,
                                   k_folds=KFOLDS, label_col=LABEL, include_ZA=INC_ZA,
                                   verbose=False, plot=False)

        mse_nn  .append(mean_squared_error(res.actual, res.nn_pred))
        mse_xgb .append(mean_squared_error(res.actual, res.xgb_pred))
        mse_rf  .append(mean_squared_error(res.actual, res.rf_pred))
        mse_meta.append(mean_squared_error(res.actual, res.stack_pred))

        r2_nn   .append(r2_score(res.actual, res.nn_pred))
        r2_xgb  .append(r2_score(res.actual, res.xgb_pred))
        r2_rf   .append(r2_score(res.actual, res.rf_pred))
        r2_meta .append(r2_score(res.actual, res.stack_pred))

    shutil.rmtree(tmpdir, ignore_errors=True)
    return dict(Z=z, A=a,
                mse_nn=np.mean(mse_nn),   mse_xgb=np.mean(mse_xgb),
                mse_rf=np.mean(mse_rf),   mse_meta=np.mean(mse_meta),
                r2_nn=np.mean(r2_nn),     r2_xgb=np.mean(r2_xgb),
                r2_rf=np.mean(r2_rf),     r2_meta=np.mean(r2_meta))

# ── Execute our workload slice ─────────────────────────────────────────
local = [evaluate_iso(int(z), int(a)) for z, a in tasks]
gathered = comm.gather(local, root=0)

# ── Save results ───────────────────────────────────────────────────────
if rank == 0:
    flat = [d for sub in gathered for d in sub]
    pd.DataFrame(flat).sort_values("A").to_csv(out_path, index=False)
    print(f"[DONE] Group {GROUP}: saved {len(flat)} rows → {out_path}", flush=True)
