#!/usr/bin/env python3
# meta_stack.py
"""
Drop-in replacement for LinBinMeta.bin_stack
===========================================

* Trains a RidgeCV meta-learner on out-of-fold predictions of NN6 / GBRT / RF6.
* Returns a DataFrame with the **same columns** as bin_stack so BigCode logic
  remains untouched.

Typical use
-----------
    from meta_stack import meta_stack
    combo = meta_stack("train.csv", "target.csv", k_folds=5)
"""

from __future__ import annotations
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_error, r2_score

# ----------------------------------------------------------------------
# Base-model helpers (assumed importable from PYTHONPATH)
# ----------------------------------------------------------------------
from NN6  import predict_nn
from GBRT import predict_xgb
from RF6  import predict_rf

# ───────────────────────── helper utilities ────────────────────────────
def _energy_fraction(df: pd.DataFrame) -> np.ndarray:
    """Normalise ENG to [0,1] within each (Z,A) isotope."""
    grp = df.groupby(["Z", "A"])["ENG"]
    return (df["ENG"] - grp.transform("min")) / (grp.transform("max") - grp.transform("min"))

def _merge_iso(df_pred: pd.DataFrame, csv_path: str | Path) -> pd.DataFrame:
    """Attach Z/A columns to a predictions DataFrame."""
    iso_cols = pd.read_csv(csv_path)[["ERG", "Z", "A"]].rename(columns={"ERG": "ENG"})
    return df_pred.merge(iso_cols, on="ENG")

def _feature_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Return the meta-features used by RidgeCV."""
    return df[["nn_pred", "xgb_pred", "rf_pred", "Z", "A", "ENG", "f"]]

# ─────────────────────────── main interface ────────────────────────────
def meta_stack(
    train_csv: str | Path,
    target_csv: str | Path,
    *,
    k_folds: int = 5,
    verbose: bool = False,
    plot: bool = False,
) -> pd.DataFrame:
    """
    Parameters
    ----------
    train_csv, target_csv : str | Path
        CSVs expected by predict_nn / predict_xgb / predict_rf.
    k_folds : int, default 5
        Number of CV folds for out-of-fold meta-training.
    verbose, plot : bool
        Diagnostics and scatter plot toggle.

    Returns
    -------
    pd.DataFrame
        Columns: ENG, actual, nn_pred, xgb_pred, rf_pred, stack_pred, Z, A, f
    """

    train_csv  = Path(train_csv).resolve()
    target_csv = Path(target_csv).resolve()

    if not train_csv.exists() or not target_csv.exists():
        raise FileNotFoundError("train_csv or target_csv not found")

    # ----------- 1) Out-of-fold predictions for meta-training ------------
    train_df = pd.read_csv(train_csv)
    indices  = np.arange(len(train_df))
    kf = KFold(n_splits=k_folds, shuffle=True, random_state=42)

    oof_chunks: list[pd.DataFrame] = []
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        for fold, (tr_idx, va_idx) in enumerate(kf.split(indices), 1):
            tr_path = tmpdir / f"fold{fold}_train.csv"
            va_path = tmpdir / f"fold{fold}_valid.csv"
            train_df.iloc[tr_idx].to_csv(tr_path, index=False)
            train_df.iloc[va_idx].to_csv(va_path, index=False)

            df_nn  = predict_nn (tr_path, va_path)
            df_xgb = predict_xgb(tr_path, va_path)
            df_rf  = predict_rf (tr_path, va_path)

            fold_df = (
                _merge_iso(df_nn, va_path)[["ENG", "Z", "A", "actual", "nn_pred"]]
                .merge(df_xgb[["ENG", "xgb_pred"]], on="ENG")
                .merge(df_rf [["ENG", "rf_pred"]], on="ENG")
                .sort_values(["Z", "A", "ENG"], kind="mergesort")
                .reset_index(drop=True)
            )
            fold_df["f"] = _energy_fraction(fold_df)
            oof_chunks.append(fold_df)

    meta_train = pd.concat(oof_chunks, ignore_index=True)
    X_meta = _feature_frame(meta_train)
    y_meta = meta_train["actual"].astype(float).values

    meta_model = Pipeline([
        ("scaler", StandardScaler()),
        ("ridge",  RidgeCV(alphas=np.logspace(-6, 3, 30)))
    ]).fit(X_meta, y_meta)

    # ----------- 2) Final predictions on TARGET --------------------------
    df_nn_te  = predict_nn (train_csv, target_csv)
    df_xgb_te = predict_xgb(train_csv, target_csv)
    df_rf_te  = predict_rf (train_csv, target_csv)

    te = (
        _merge_iso(df_nn_te, target_csv)[["ENG", "Z", "A", "actual", "nn_pred"]]
        .merge(df_xgb_te[["ENG", "xgb_pred"]], on="ENG")
        .merge(df_rf_te[ ["ENG", "rf_pred"]], on="ENG")
        .sort_values(["Z", "A", "ENG"], kind="mergesort")
        .reset_index(drop=True)
    )
    te["f"] = _energy_fraction(te)

    X_te = _feature_frame(te)
    te["stack_pred"] = meta_model.predict(X_te)

    # ----------- 3) Optional diagnostics ---------------------------------
    if verbose and te["actual"].notna().any():
        mse = mean_squared_error(te["actual"], te["stack_pred"])
        r2  = r2_score       (te["actual"], te["stack_pred"])
        print(f"[meta_stack] RidgeCV  MSE={mse:.5e}  R²={r2:.4f}")

    if plot:
        png = target_csv.with_suffix("").name + "_META.png"
        plt.figure(figsize=(8,5))
        plt.scatter(te["ENG"], te["actual"],     label="Actual", marker="o", alpha=.8)
        plt.scatter(te["ENG"], te["nn_pred"],    label="NN",     marker="x")
        plt.scatter(te["ENG"], te["xgb_pred"],   label="XGB",    marker="+")
        plt.scatter(te["ENG"], te["rf_pred"],    label="RF",     marker="^")
        plt.scatter(te["ENG"], te["stack_pred"], label="Meta",   marker="*", s=70, c="black")
        plt.xlabel("Energy (MeV)"); plt.ylabel("Cross Section (XS)")
        plt.title("Ridge meta-learner predictions"); plt.legend(); plt.tight_layout()
        plt.savefig(png, dpi=200)
        if verbose:
            print(f"Plot saved → {png}")

    return te

# ─────────────────────── stand-alone CLI helper ───────────────────────────
if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Run Ridge meta-stacker once.")
    p.add_argument("train_csv",  help="CSV used to train base models")
    p.add_argument("target_csv", help="CSV to predict (and evaluate if labels available)")
    p.add_argument("--folds", type=int, default=5, help="K-folds for OOF training")
    p.add_argument("--plot",  action="store_true", help="Save scatter plot")
    args = p.parse_args()

    meta_stack(args.train_csv, args.target_csv,
               k_folds=args.folds, verbose=True, plot=args.plot)
