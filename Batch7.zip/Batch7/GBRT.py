import sys as _sys
import pandas as _pd
import numpy as _np
import xgboost as _xgb
from sklearn.metrics import mean_squared_error as _mse

PARAMS_XGB = dict(
    n_estimators=900,
    max_depth=8,
    learning_rate=0.029712960622239035,
    subsample=0.8,
    colsample_bytree=0.824,
    reg_lambda=1.2631575298699964,
)


def _build_xgb():
    return _xgb.XGBRegressor(objective="reg:squarederror", n_jobs=-1, verbosity=0, **PARAMS_XGB)


def predict_xgb(train_csv: str, target_csv: str) -> _pd.DataFrame:
    train = _pd.read_csv(train_csv)
    test  = _pd.read_csv(target_csv)

    X_train, y_train = train.drop(columns=["XS"]), train["XS"].values
    X_test,  y_test  = test.drop(columns=["XS", "XSlow", "XSupp"], errors="ignore"), test["XS"].values

    model = _build_xgb().fit(X_train, y_train)
    y_pred = model.predict(X_test)

    out = _pd.DataFrame({
        "ENG": X_test.get("ERG", _np.arange(len(X_test))).astype(float),
        "actual": y_test,
        "xgb_pred": y_pred,
    })
    out["xgb_err"] = out["xgb_pred"] - out["actual"]
    return out


if __name__ == "__main__":
    tr, tgt, out_csv = _sys.argv[1:4] if len(_sys.argv) >= 4 else (
        "..\\Batch5\\train4.csv", "..\\Batch5\\target4.csv", "predictions_xgb.csv")
    df_out = predict_xgb(tr, tgt)
    df_out.to_csv(out_csv, index=False)
    print(f"XGB predictions written to {out_csv}  (MSE={_mse(df_out.actual, df_out.xgb_pred):.4e})")