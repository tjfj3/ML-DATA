#!/usr/bin/env python3
# MetaXGB.py
# ------------------------------------------------------------
# XGBRegressor meta-stacker with GroupKFold (by isotope Z-A)
# Features = {base preds, f-gated preds, f, ENG (+poly), Z, A,
#             plus simple interactions}.
# Key-aligned merges avoid row-order drift; option to balance
# isotopes and to tune the main XGB parameters from CLI.
# ------------------------------------------------------------

from __future__ import annotations
from pathlib import Path
import tempfile, json, warnings
import numpy as np, pandas as pd, matplotlib.pyplot as plt

from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from xgboost import XGBRegressor

# base helpers -------------------------------------------------------------
from NN6  import predict_nn
from GBRT import predict_xgb as predict_gbrt    # avoid name clash
from RF6  import predict_rf

# ------------------ feature helpers --------------------------------------
def _energy_fraction(df: pd.DataFrame) -> np.ndarray:
    by_iso = df.groupby(["Z", "A"])["ENG"]
    return (df["ENG"] - by_iso.transform("min")) / (by_iso.transform("max") - by_iso.transform("min"))

def _make_features(
        df: pd.DataFrame,
        *,
        include_ZA  : bool,
        include_ENG : bool,
        eng_poly    : int,
        add_inter   : bool = True,
) -> pd.DataFrame:
    f  = df["f"].values
    nn = df["nn_pred"].values
    gx = df["xgb_pred"].values
    rf = df["rf_pred"].values

    X = pd.DataFrame({
        "nn"    : nn,   "xgb"   : gx,   "rf"   : rf,
        "nn_f"  : nn*f, "xgb_f" : gx*f, "rf_f" : rf*f,
        "f"     : f,
    })

    # --- ENG & polynomial terms -----------------------------------------
    if include_ENG:
        eng = df["ENG"].values
        X["ENG"] = eng
        if eng_poly >= 2:
            eng2 = eng*eng
            X["ENG2"] = eng2
        if eng_poly >= 3:
            X["ENG3"] = eng*eng*eng

        if add_inter:
            X["nn_eng"]   = nn*eng
            X["xgb_eng"]  = gx*eng
            X["rf_eng"]   = rf*eng
            if eng_poly >= 2:
                X["nn_eng2"]  = nn*eng2
                X["xgb_eng2"] = gx*eng2
                X["rf_eng2"]  = rf*eng2

    # --- Z / A -----------------------------------------------------------
    if include_ZA:
        Z, A = df["Z"].values, df["A"].values
        X["Z"] = Z; X["A"] = A
        if add_inter:
            X["nn_Z"] = nn*Z; X["xgb_Z"]=gx*Z; X["rf_Z"]=rf*Z
            X["nn_A"] = nn*A; X["xgb_A"]=gx*A; X["rf_A"]=rf*A

    # cheap nonlinearities
    if add_inter:
        X["nn_xgb"] = nn*gx; X["nn_rf"] = nn*rf; X["xgb_rf"] = gx*rf
        X["nn2"]    = nn*nn; X["xgb2"] = gx*gx; X["rf2"] = rf*rf

    return X

def _merge_iso(df_pred: pd.DataFrame, csv_path: str|Path) -> pd.DataFrame:
    iso = pd.read_csv(csv_path)[["ERG","Z","A"]].rename(columns={"ERG":"ENG"})
    return df_pred.merge(iso, on="ENG")

# ------------------ main entry point -------------------------------------
def meta_xgb_gkf_stack(
        train_csv : str|Path,
        target_csv: str|Path,
        *,
        k_folds      : int   = 5,
        label_col    : str   = "XS",
        include_ZA   : bool  = True,
        include_ENG  : bool  = True,
        eng_poly     : int   = 1,
        balance_groups : bool = False,
        # --- XGB hyper-params (sane defaults for smallish meta data) -----
        xgb_params: dict|None = None,
        n_estimators : int = 300,
        lr           : float = 0.05,
        max_depth    : int   = 5,
        subsample    : float = 0.8,
        colsample_bytree: float = 0.8,
        verbose      : bool  = False,
        plot         : bool  = False,
) -> pd.DataFrame:
    """
    Returns a DataFrame with ENG, Z, A, base preds and stack_pred.
    """

    train_csv, target_csv = Path(train_csv).resolve(), Path(target_csv).resolve()

    # 1) ---------------- build OOF meta-train ---------------------------
    tr_df   = pd.read_csv(train_csv).reset_index(drop=True)
    groups  = tr_df["Z"].astype(str) + "_" + tr_df["A"].astype(str)
    gkf     = GroupKFold(n_splits=k_folds)
    oof_buf : list[pd.DataFrame] = []

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        for fold, (tr_idx, va_idx) in enumerate(gkf.split(tr_df, groups=groups)):
            tr_part, va_part = tr_df.iloc[tr_idx].copy(), tr_df.iloc[va_idx].copy().reset_index(drop=True)
            p_tr, p_va = tmp/f"tr{fold}.csv", tmp/f"va{fold}.csv"
            tr_part.to_csv(p_tr, index=False); va_part.to_csv(p_va, index=False)

            df_nn  = _merge_iso(predict_nn (p_tr, p_va), p_va)[["ENG","Z","A","nn_pred"]]
            df_gx  = _merge_iso(predict_gbrt(p_tr, p_va), p_va)[["ENG","Z","A","xgb_pred"]]
            df_rf  = _merge_iso(predict_rf (p_tr, p_va), p_va)[["ENG","Z","A","rf_pred"]]

            merged = (va_part[["ERG","Z","A"]].rename(columns={"ERG":"ENG"})
                        .merge(df_nn, on=["ENG","Z","A"])
                        .merge(df_gx, on=["ENG","Z","A"])
                        .merge(df_rf, on=["ENG","Z","A"])
                        .sort_values(["Z","A","ENG"], kind="mergesort")
                        .reset_index(drop=True))
            if label_col in va_part.columns:
                merged["actual"] = va_part[label_col].values
            merged["f"] = _energy_fraction(merged)
            oof_buf.append(merged)

    meta_train = pd.concat(oof_buf, ignore_index=True)

    # 2) ---------------- targets & features ----------------------------
    y_tr = meta_train["actual"].astype(float).to_numpy()
    X_tr = _make_features(meta_train,
                          include_ZA=include_ZA,
                          include_ENG=include_ENG,
                          eng_poly=eng_poly,
                          add_inter=True)

    if balance_groups:
        grp = meta_train["Z"].astype(str)+"_"+meta_train["A"].astype(str)
        w = grp.map(lambda g: 1.0/grp.value_counts()[g]).values
    else:
        w = None

    # 3) ---------------- XGB regressor ---------------------------------
    if xgb_params is None:
        xgb_params = dict(
            objective="reg:squarederror",
            n_estimators=n_estimators,
            learning_rate=lr,
            max_depth=max_depth,
            subsample=subsample,
            colsample_bytree=colsample_bytree,
            reg_lambda=1.0,
            reg_alpha=0.0,
            n_jobs=1,               # keep single-threaded; MPI gives us parallelism
            random_state=42,
        )
    xgb = XGBRegressor(**xgb_params)
    # scale features first – pipeline ensures identical transform for test
    model = Pipeline([("scaler", StandardScaler()), ("xgb", xgb)])
    model.fit(X_tr, y_tr, xgb__sample_weight=w)

    if verbose:
        preds_tr = model.predict(X_tr)
        mse = mean_squared_error(y_tr, preds_tr)
        r2  = r2_score(y_tr, preds_tr)
        print(f"[OOF-fit] XGB meta  k={k_folds}  MSE={mse:.6f}  R²={r2:.6f}")

    # 4) ---------------- final TARGET prediction -----------------------
    tgt_df  = pd.read_csv(target_csv).reset_index(drop=True)
    base    = tgt_df[["ERG","Z","A"]].rename(columns={"ERG":"ENG"})
    nn_te   = _merge_iso(predict_nn (train_csv, target_csv), target_csv)[["ENG","Z","A","nn_pred"]]
    gx_te   = _merge_iso(predict_gbrt(train_csv, target_csv), target_csv)[["ENG","Z","A","xgb_pred"]]
    rf_te   = _merge_iso(predict_rf (train_csv, target_csv), target_csv)[["ENG","Z","A","rf_pred"]]

    te = (base.merge(nn_te,on=["ENG","Z","A"])
               .merge(gx_te,on=["ENG","Z","A"])
               .merge(rf_te,on=["ENG","Z","A"])
               .sort_values(["Z","A","ENG"], kind="mergesort")
               .reset_index(drop=True))
    if label_col in tgt_df.columns:
        te["actual"] = tgt_df[label_col].values
    te["f"] = _energy_fraction(te)

    X_te = _make_features(te,
                          include_ZA=include_ZA,
                          include_ENG=include_ENG,
                          eng_poly=eng_poly,
                          add_inter=True)
    te["stack_pred"] = model.predict(X_te)

    if verbose and "actual" in te and te["actual"].notna().any():
        mse_t = mean_squared_error(te["actual"], te["stack_pred"])
        r2_t  = r2_score       (te["actual"], te["stack_pred"])
        print(f"[TARGET] XGB meta  MSE={mse_t:.6f}  R²={r2_t:.6f}")

    # optional diagnostic plot -----------------------------------------
    if plot:
        out_png = target_csv.with_suffix("").name + "_MetaXGB.png"
        plt.figure(figsize=(8,5))
        if "actual" in te:
            plt.scatter(te["ENG"], te["actual"], label="Actual", marker="o", alpha=.8)
        plt.scatter(te["ENG"], te["nn_pred"],  label="NN",   marker="x")
        plt.scatter(te["ENG"], te["xgb_pred"], label="XGB",  marker="+")
        plt.scatter(te["ENG"], te["rf_pred"],  label="RF",   marker="^")
        plt.scatter(te["ENG"], te["stack_pred"], label="Meta-XGB", marker="*", c="black", s=70)
        plt.xlabel("Energy (MeV)"); plt.ylabel("Cross-section (XS)")
        plt.title("XGB meta-learner (GroupKFold OOF)")
        plt.legend(); plt.tight_layout(); plt.savefig(out_png, dpi=220)
        print(f"Plot saved → {out_png}")

    return te

# --------------------- handy CLI ----------------------------------------
if __name__ == "__main__":
    import argparse, json
    p = argparse.ArgumentParser()
    p.add_argument("train_csv"); p.add_argument("target_csv")
    p.add_argument("--folds", type=int, default=5)
    p.add_argument("--include-ZA",  action="store_true")
    p.add_argument("--include-ENG", action="store_true")
    p.add_argument("--eng-poly", type=int, default=1, choices=[1,2,3])
    p.add_argument("--balance-groups", action="store_true")
    p.add_argument("--xgb-params-json", help="Override default XGB params (JSON dict)")
    p.add_argument("--plot", action="store_true"); p.add_argument("--verbose", action="store_true")
    a = p.parse_args()

    params = json.loads(a.xgb_params_json) if a.xgb_params_json else None
    meta_xgb_gkf_stack(
        a.train_csv, a.target_csv,
        k_folds=a.folds,
        include_ZA=a.include_ZA,
        include_ENG=a.include_ENG,
        eng_poly=a.eng_poly,
        balance_groups=a.balance_groups,
        xgb_params=params,
        verbose=a.verbose,
        plot=a.plot,
    )
