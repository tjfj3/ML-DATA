#!/usr/bin/env python3
"""
Combined plot (hard-coded): per-isotope ΔMSE vs *equally spaced* isotope index
for multiple meta models, using the BEST BASE from the SAME CSV.

Also produces a summary scatter: per-meta-model point at
   x = average mse_meta
   y = percent of isotopes where meta is the winner
"""

import pathlib
import sys
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ───────────────────────── EDIT HERE ─────────────────────────
META_MODELS = ["Ridge1", "Ridge3", "Ridge4", "Ridge6"]   # your meta model names
CSV_DIR = pathlib.Path("Data")
OUT_DIR = pathlib.Path("MetaAnnalysis")

# existing outputs
OUT_PNG = OUT_DIR / "Iso_Meta_Performance.png"
OUT_SUM = OUT_DIR / "Iso_Meta_Performance.csv"

# NEW: second plot (summary scatter across meta models)
OUT_PNG_SUMMARY = OUT_DIR / "Meta_WinRate_vs_MSE.png"
LOG_X_SUMMARY   = True   # ← set True to log the x-axis of the summary scatter
INVERT_X_SUMMARY = False 

JITTER_SPAN = 0.25     # +/- x-offset so points at same isotope don't overlap
USE_SYMLOG  = True     # set True to "log" the difference with a symmetric log y-scale
X_LABEL_MODE = "A"     # "A" to label by mass number, "ZA" to label by "Z-A"
TICK_COUNT  = 20       # approx number of x ticks to show (to avoid clutter)
# ────────────────────────────────────────────────────────────

BASE_COLS = ["mse_nn", "mse_xgb", "mse_rf"]
META_COL  = "mse_meta"

def _safe_numeric(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df

def _load_and_group(name: str):
    """Load one meta CSV, coerce numerics, and group by (Z,A)."""
    path = CSV_DIR / f"{name}_benchmark_full.csv"
    if not path.exists():
        raise FileNotFoundError(f"Missing file: {path}")

    df = pd.read_csv(path)

    # Legacy rename
    if META_COL not in df.columns and "mse_st" in df.columns:
        df = df.rename(columns={"mse_st": META_COL})

    need = {"Z", "A", META_COL, *BASE_COLS}
    missing = [c for c in need if c not in df.columns]
    if missing:
        raise ValueError(f"{path.name}: missing columns {missing}")

    df = _safe_numeric(df, list(need)).dropna(subset=list(need)).reset_index(drop=True)

    # Average duplicates per isotope (Z,A)
    agg = df.groupby(["Z", "A"], as_index=False).agg({
        "Z": "first",
        "A": "first",
        "mse_nn": "mean",
        "mse_xgb": "mean",
        "mse_rf": "mean",
        META_COL: "mean",
    })

    return name, path, agg

def _build_isotope_index(all_frames: list[pd.DataFrame]) -> tuple[pd.DataFrame, dict, dict]:
    """
    Build a global ordering of isotopes across all inputs, sorted by (A,Z).
    Returns:
      order_df with columns Z,A, POS (0..N-1)
      pos_map: {(Z,A) -> POS}
      label_map: {POS -> label str} based on X_LABEL_MODE
    """
    concat = pd.concat(all_frames, axis=0, ignore_index=True)[["Z", "A"]].drop_duplicates()
    order_df = concat.sort_values(["A", "Z"], kind="mergesort").reset_index(drop=True)
    order_df["POS"] = np.arange(len(order_df), dtype=int)

    pos_map = {(int(z), int(a)): int(pos) for z, a, pos in order_df[["Z","A","POS"]].itertuples(index=False, name=None)}

    if X_LABEL_MODE.upper() == "ZA":
        labels = [f"{int(z)}-{int(a)}" for z, a in order_df[["Z","A"]].itertuples(index=False, name=None)]
    else:  # "A"
        labels = [f"{int(a)}" for a in order_df["A"]]

    label_map = {int(pos): lab for pos, lab in zip(order_df["POS"], labels)}
    return order_df, pos_map, label_map

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # Load all meta CSVs
    loaded = []
    frames_for_index = []
    for name in META_MODELS:
        try:
            item = _load_and_group(name)
            loaded.append(item)
            frames_for_index.append(item[2][["Z","A"]])
        except Exception as e:
            print(f"[ERROR] {e}", file=sys.stderr)

    if not loaded:
        print("No valid inputs. Check META_MODELS and CSV_DIR.", file=sys.stderr)
        sys.exit(1)

    # Build a global isotope index (equal spacing) across all files
    order_df, pos_map, label_map = _build_isotope_index(frames_for_index)

    # Prepare combined plot data & per-model summaries
    offsets = np.linspace(-JITTER_SPAN, JITTER_SPAN, num=len(loaded))
    plot_data = []
    summaries = []

    # We'll also collect summary points here:
    summary_points = []   # list of (model_name, avg_mse_meta, win_pct_meta)

    for (offset, (name, path, df)) in zip(offsets, loaded):
        # Compute ΔMSE vs best base within THIS CSV, per (Z,A)
        best_base = df[BASE_COLS].min(axis=1).to_numpy()
        meta = df[META_COL].to_numpy()
        dlt = meta - best_base

        # Map (Z,A) to equal-spaced positions
        pos = np.array([pos_map.get((int(z), int(a)), None) for z, a in df[["Z","A"]].itertuples(index=False, name=None)], dtype=float)
        mask = ~np.isnan(pos)
        pos = pos[mask]
        dlt = dlt[mask]

        # Averages over isotopes
        avg_nn   = float(df["mse_nn"].mean())
        avg_xgb  = float(df["mse_xgb"].mean())
        avg_rf   = float(df["mse_rf"].mean())
        avg_meta = float(df[META_COL].mean())

        # Win-rate per model: which has the lowest MSE on each isotope?
        mse_cols_all = ["mse_nn", "mse_xgb", "mse_rf", META_COL]
        vals = df[mse_cols_all].to_numpy()
        winners = np.argmin(vals, axis=1)          # ties break by column order
        N = len(winners)
        counts = np.bincount(winners, minlength=4)
        perc   = 100.0 * counts / max(N, 1)

        win_map = {
            "nn":   (counts[0], perc[0]),
            "xgb":  (counts[1], perc[1]),
            "rf":   (counts[2], perc[2]),
            "meta": (counts[3], perc[3]),
        }

        # Console output
        print(f"\n=== {name} ({path.name}) ===")
        print(f"mse_nn   avg = {avg_nn: .6e}, win_rate= {win_map['nn'][1]:4.1f}% ({win_map['nn'][0]}/{N})")
        print(f"mse_xgb  avg = {avg_xgb: .6e}, win_rate= {win_map['xgb'][1]:4.1f}% ({win_map['xgb'][0]}/{N})")
        print(f"mse_rf   avg = {avg_rf: .6e}, win_rate= {win_map['rf'][1]:4.1f}% ({win_map['rf'][0]}/{N})")
        print(f"mse_meta avg = {avg_meta: .6e}, win_rate= {win_map['meta'][1]:4.1f}% ({win_map['meta'][0]}/{N})")

        # Summary row (also saved to CSV)
        summaries.append({
            "model": name,
            "n_isotopes": int(N),
            "avg_mse_nn":   avg_nn,
            "avg_mse_xgb":  avg_xgb,
            "avg_mse_rf":   avg_rf,
            "avg_mse_meta": avg_meta,
            "win_cnt_nn":   int(win_map["nn"][0]),
            "win_cnt_xgb":  int(win_map["xgb"][0]),
            "win_cnt_rf":   int(win_map["rf"][0]),
            "win_cnt_meta": int(win_map["meta"][0]),
            "win_pct_nn":   float(win_map["nn"][1]),
            "win_pct_xgb":  float(win_map["xgb"][1]),
            "win_pct_rf":   float(win_map["rf"][1]),
            "win_pct_meta": float(win_map["meta"][1]),
        })

        # For the new summary scatter (one point per meta model)
        summary_points.append((name, avg_meta, float(win_map["meta"][1])))

        # Sort by position and add small jitter per model (existing plot)
        order = np.argsort(pos)
        plot_data.append((name, pos[order] + offset, dlt[order]))

    # ───────── Existing combined per-isotope plot ─────────
    plt.figure(figsize=(11, 6))
    plt.axhline(0.0, linestyle="--", linewidth=1.0, label="meta = best base (same CSV)")

    for name, Px, dy in plot_data:
        plt.scatter(Px, dy, s=16, alpha=0.65, label=name)

    if USE_SYMLOG:
        plt.yscale("symlog", base=10, linthresh=1e-4, linscale=1.0)
        plt.ylabel("ΔMSE = MSE_meta − min{mse_nn, mse_xgb, mse_rf}  (symlog y-scale)")
    else:
        plt.ylabel("ΔMSE = MSE_meta − min{mse_nn, mse_xgb, mse_rf}")

    # Build sparse x ticks
    N = len(order_df)
    if N > 1:
        step = max(1, N // TICK_COUNT)
        tick_pos = np.arange(0, N, step, dtype=int)
        tick_labels = [label_map[p] for p in tick_pos]
        plt.xticks(tick_pos, tick_labels, rotation=45, ha="right")
    plt.xlim(-0.5, N - 0.5)

    plt.xlabel("Isotopes (equally spaced; ordered by A then Z)")
    plt.title("Meta vs BEST BASE per Isotope — Combined (equal spacing)")
    plt.legend(ncol=2, fontsize=9)
    plt.tight_layout()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    plt.savefig(OUT_PNG, dpi=220)
    plt.close()
    print(f"\nCombined plot saved → {OUT_PNG}")

    # ───────── NEW: summary scatter (one point per meta model) ─────────
    if summary_points:
        names, x_mse, y_pct = zip(*summary_points)

        fig, ax = plt.subplots(figsize=(7.5, 5.5))
        ax.scatter(x_mse, y_pct, s=60, alpha=0.9)

        # label points with model names
        for n, x, y in zip(names, x_mse, y_pct):
            ax.annotate(n, (x, y), textcoords="offset points", xytext=(6, 4), fontsize=9)

        if LOG_X_SUMMARY:
            ax.set_xscale("log")        # works fine with inversion too

        if INVERT_X_SUMMARY:
            ax.invert_xaxis()           # lower MSE appears to the RIGHT

        ax.set_xlabel("Average MSE of meta model")
        ax.set_ylabel("Win rate (% of isotopes where meta is best)")
        ax.set_title("Meta models: Win rate vs Average MSE")
        ax.grid(True, which="both", axis="both", linestyle=":", linewidth=0.6, alpha=0.6)
        fig.tight_layout()
        fig.savefig(OUT_PNG_SUMMARY, dpi=220)
        plt.close(fig)
        print(f"Summary scatter saved → {OUT_PNG_SUMMARY}")


    # Save summary table (unchanged schema; already contains bytes we need)
    pd.DataFrame(summaries).to_csv(OUT_SUM, index=False)
    print(f"Summary saved → {OUT_SUM}")

if __name__ == "__main__":
    main()
