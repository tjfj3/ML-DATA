#!/usr/bin/env python3
"""
make_full_mse_plot.py
─────────────────────
Merge S/M/L slice results, plot log-MSE vs A, and tell you where the
stacked model is beaten by NN, XGB, or RF.

Outputs
-------
stack_benchmark_full.csv
mse_per_iso_full.png
stack_worse_than.csv     (only those isotopes where Stack is worse)
"""

import pathlib
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

here = pathlib.Path(".").resolve()

# ── 1. merge slice CSVs ─────────────────────────────────────────────
dfs = [pd.read_csv(here / f"Data/Ridge2_benchmark_iso_{lbl}.csv") for lbl in "SML"]
full = pd.concat(dfs, ignore_index=True).sort_values("A")
full.to_csv("Data/Ridge2_benchmark_full.csv", index=False)
print(f"[OK] merged → Ridge2_benchmark_full.csv  ({len(full)} rows)\n")

# ── 2. log-MSE vs A plot ────────────────────────────────────────────
plt.figure(figsize=(8,5))
plt.plot(full["A"], full["mse_nn"],  marker="x", label="NN")
plt.plot(full["A"], full["mse_xgb"], marker="+", label="XGB")
plt.plot(full["A"], full["mse_rf"],  marker="^", label="RF")
plt.plot(full["A"], full["mse_meta"],  marker="*", label="Bin")

plt.xlabel("Mass number A")
plt.ylabel("MSE  (log$_{10}$ scale)")
plt.yscale("log")
plt.title("MSE vs A  (all isotopes, bins = 10)")
plt.tight_layout(); plt.legend()
plt.savefig("IsoPlots/Ridge2_per_iso_full.png", dpi=300)
print("[OK] plot saved → Ridge2_mse_per_iso.png\n")

# ── 3. where is Stack worse? ────────────────────────────────────────
def beaters(row):
    losers = []
    if row["mse_nn"]  < row["mse_meta"]: losers.append("NN")
    if row["mse_xgb"] < row["mse_meta"]: losers.append("XGB")
    if row["mse_rf"]  < row["mse_meta"]: losers.append("RF")
    return ", ".join(losers)

full["beaters"] = full.apply(beaters, axis=1)
worse = full.loc[full["beaters"] != "", ["Z", "A", "mse_st", "beaters"]]
worse.to_csv("stack_worse_than.csv", index=False)

print("Stack beaten on these isotopes (Z-A):")
if worse.empty:
    print("  None 🎉  (Stack best everywhere)")
else:
    for _, r in worse.iterrows():
        tag = f"{int(r.Z)}-{int(r.A)}"
        print(f"  {tag:<7}  Stack MSE={r.mse_st:.3e}  beaten by → {r.beaters}")
    print(f"\n[OK] detailed list written to stack_worse_than.csv")

# ── 4. average MSE per model ───────────────────────────────────────
avg_mse = full[["mse_nn","mse_xgb","mse_rf","mse_st"]].mean()

print("\nAverage MSE across all isotopes")
print("Model   |    MSE")
print("------------------------")
for label, val in zip(["NN","XGB","RF","Stack"], avg_mse.values):
    print(f"{label:<6} | {val:10.4e}")
print("------------------------")
