#!/usr/bin/env python3
# meta_ridge_gkf.py  (improved)
# RidgeCV meta-learner with GroupKFold by isotope, energy-aware + nucleus-aware features,
# interactions so per-row trust varies with f/ENG/Z/A, optional log-space and group weighting.

from __future__ import annotations
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_error, r2_score

# Base helpers must be importable (same folder or on PYTHONPATH)
from NN6  import predict_nn
from GBRT import predict_xgb
from RF6  import predict_rf

# ───────────────────────── helpers ─────────────────────────
def _energy_fraction(df: pd.DataFrame) -> np.ndarray:
    """Normalise ENG to [0,1] within each isotope (Z,A)."""
    by_iso = df.groupby(["Z", "A"])["ENG"]
    return (df["ENG"] - by_iso.transform("min")) / (by_iso.transform("max") - by_iso.transform("min"))

def _make_features(
    df: pd.DataFrame,
    *,
    include_ZA: bool,
    include_ENG: bool,
    eng_poly: int,
    add_interactions: bool = True,
) -> pd.DataFrame:
    """
    Build meta features. Always includes base preds and f-gated versions.
    Optionally add raw ENG (+ low-order poly) and Z/A, and interactions
    so the effective weight on each base can vary per row with f/ENG/Z/A.
    """
    f  = df["f"].values
    nn = df["nn_pred"].values
    xg = df["xgb_pred"].values
    rf = df["rf_pred"].values

    X = pd.DataFrame({
        # base predictions
        "nn": nn, "xgb": xg, "rf": rf,
        # energy gating (already lets weights vary with f)
        "nn_f": nn * f, "xgb_f": xg * f, "rf_f": rf * f,
        "f": f,
    })

    if include_ENG:
        eng = df["ENG"].values
        X["ENG"] = eng
        if eng_poly >= 2:
            eng2 = eng * eng
            X["ENG2"] = eng2
        if eng_poly >= 3:
            X["ENG3"] = eng * eng * eng

        if add_interactions:
            # allow base weights to depend on absolute energy, not only f
            X["nn_eng"]  = nn * eng
            X["xgb_eng"] = xg * eng
            X["rf_eng"]  = rf * eng
            if eng_poly >= 2:
                X["nn_eng2"]  = nn * eng2
                X["xgb_eng2"] = xg * eng2
                X["rf_eng2"]  = rf * eng2

    if include_ZA:
        Z = df["Z"].values; A = df["A"].values
        X["Z"] = Z; X["A"] = A
        if add_interactions:
            # let base weights depend on nucleus identity
            X["nn_Z"]  = nn * Z;  X["xgb_Z"] = xg * Z;  X["rf_Z"]  = rf * Z
            X["nn_A"]  = nn * A;  X["xgb_A"] = xg * A;  X["rf_A"]  = rf * A

    # Cheap nonlinearity helpful for Ridge (kept small)
    if add_interactions:
        X["nn_xgb"] = nn * xg
        X["nn_rf"]  = nn * rf
        X["xgb_rf"] = xg * rf
        X["nn2"]    = nn * nn
        X["xgb2"]   = xg * xg
        X["rf2"]    = rf * rf

    return X

# ───────────────────────── main API ─────────────────────────
def meta_ridge_gkf_stack(
    train_csv: str | Path,
    target_csv: str | Path,
    *,
    k_folds: int = 5,
    label_col: str = "XS",
    include_ZA: bool = True,
    include_ENG: bool = True,
    eng_poly: int = 1,                  # 1=ENG, 2=ENG+ENG^2, 3=+ENG^3
    use_log: bool = False,              # train meta on log1p(y), return expm1(pred)
    balance_groups: bool = False,       # equalize isotope influence in meta fit
    verbose: bool = False,
    plot: bool = False,
) -> pd.DataFrame:
    """
    Train a RidgeCV meta-learner using GroupKFold by isotope (Z,A) on TRAIN,
    then predict TARGET. Predictions are aligned by row order (no ENG merge).

    Returns DataFrame with columns:
      ENG, Z, A, actual (if available), nn_pred, xgb_pred, rf_pred, f, stack_pred
      (plus any plotting side-effects if enabled)
    """
    train_csv  = Path(train_csv).resolve()
    target_csv = Path(target_csv).resolve()

    # 1) Build OOF meta-train on TRAIN (leakage-free) using GroupKFold by isotope
    train_df = pd.read_csv(train_csv).reset_index(drop=True)
    groups = train_df["Z"].astype(str) + "_" + train_df["A"].astype(str)
    gkf = GroupKFold(n_splits=k_folds)

    oof_chunks: list[pd.DataFrame] = []
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        for fold, (tr_idx, va_idx) in enumerate(gkf.split(train_df, groups=groups), start=1):
            tr_df = train_df.iloc[tr_idx].copy()
            va_df = train_df.iloc[va_idx].copy().reset_index(drop=True)

            tr_path = tmpdir / f"train_fold{fold}.csv"
            va_path = tmpdir / f"valid_fold{fold}.csv"
            tr_df.to_csv(tr_path, index=False)
            va_df.to_csv(va_path, index=False)

            # base predictions for validation slice, trained on tr_path
            df_nn  = predict_nn (tr_path, va_path)
            df_xgb = predict_xgb(tr_path, va_path)
            df_rf  = predict_rf (tr_path, va_path)

            # Safe alignment-by-position
            va_merge = va_df[["ERG", "Z", "A"]].rename(columns={"ERG": "ENG"}).copy()
            if label_col in va_df.columns:
                va_merge["actual"] = va_df[label_col].values

            va_merge["nn_pred"]  = df_nn ["nn_pred"].values
            va_merge["xgb_pred"] = df_xgb["xgb_pred"].values
            va_merge["rf_pred"]  = df_rf ["rf_pred"].values
            va_merge["f"]        = _energy_fraction(va_merge)
            oof_chunks.append(va_merge)

    meta_train = pd.concat(oof_chunks, axis=0, ignore_index=True)

    # Targets (optionally log-space)
    if "actual" not in meta_train:
        raise ValueError("Training CSV must contain labels to fit the meta model.")
    if use_log:
        y_tr = np.log1p(meta_train["actual"].astype(float).values)
    else:
        y_tr = meta_train["actual"].astype(float).values

    # Features
    X_tr = _make_features(
        meta_train,
        include_ZA=include_ZA,
        include_ENG=include_ENG,
        eng_poly=int(eng_poly),
        add_interactions=True,
    )

    # Optional group-balanced weights (each isotope contributes equally)
    fit_kwargs = {}
    if balance_groups:
        grp = meta_train["Z"].astype(str) + "_" + meta_train["A"].astype(str)
        counts = grp.value_counts()
        w = grp.map(lambda g: 1.0 / counts[g]).astype(float).values
        fit_kwargs["ridge__sample_weight"] = w  # route to final step in Pipeline

    # Meta model
    meta_model = Pipeline([
        ("scaler", StandardScaler(with_mean=True, with_std=True)),
        ("ridge",  RidgeCV(alphas=np.logspace(-6, 3, 30)))
    ])
    meta_model.fit(X_tr, y_tr, **fit_kwargs)

    if verbose:
        pred_tr = meta_model.predict(X_tr)
        if use_log:
            pred_tr_eval = np.expm1(pred_tr)
            y_tr_eval    = np.expm1(y_tr)
        else:
            pred_tr_eval = pred_tr
            y_tr_eval    = y_tr
        mse_tr  = mean_squared_error(y_tr_eval, pred_tr_eval)
        r2_tr   = r2_score(y_tr_eval, pred_tr_eval)
        print(f"[TRAIN OOF-fit] RidgeCV  folds={k_folds}  "
              f"log={use_log}  balance={balance_groups}  "
              f"MSE={mse_tr:.6f}  R²={r2_tr:.6f}")

    # 2) Final TARGET predictions (no target labels used for fitting)
    target_df = pd.read_csv(target_csv).reset_index(drop=True)
    te = target_df[["ERG", "Z", "A"]].rename(columns={"ERG": "ENG"}).copy()
    if label_col in target_df.columns:
        te["actual"] = target_df[label_col].values

    df_nn_te  = predict_nn (train_csv, target_csv)
    df_xgb_te = predict_xgb(train_csv, target_csv)
    df_rf_te  = predict_rf (train_csv, target_csv)

    te["nn_pred"]  = df_nn_te["nn_pred"].values
    te["xgb_pred"] = df_xgb_te["xgb_pred"].values
    te["rf_pred"]  = df_rf_te["rf_pred"].values
    te["f"]        = _energy_fraction(te)

    X_te = _make_features(
        te,
        include_ZA=include_ZA,
        include_ENG=include_ENG,
        eng_poly=int(eng_poly),
        add_interactions=True,
    )
    te_pred = meta_model.predict(X_te)
    te["stack_pred"] = np.expm1(te_pred) if use_log else te_pred

    # Optional diagnostics & plot
    if verbose and "actual" in te and te["actual"].notna().any():
        mse = mean_squared_error(te["actual"], te["stack_pred"])
        r2  = r2_score       (te["actual"], te["stack_pred"])
        print(f"[TARGET] RidgeCV  MSE={mse:.6f}  R²={r2:.6f}")

    if plot:
        out_png = target_csv.with_suffix("").name + "_RidgeGKF_improved.png"
        plt.figure(figsize=(8,5))
        if "actual" in te:
            plt.scatter(te["ENG"], te["actual"], label="Actual", marker="o", alpha=.8)
        plt.scatter(te["ENG"], te["nn_pred"],    label="NN",  marker="x")
        plt.scatter(te["ENG"], te["xgb_pred"],   label="XGB", marker="+")
        plt.scatter(te["ENG"], te["rf_pred"],    label="RF",  marker="^")
        plt.scatter(te["ENG"], te["stack_pred"], label="Meta (Ridge+GKF+ENG+ZA)", marker="*", s=70, c="black")
        plt.xlabel("Energy (MeV)"); plt.ylabel("Cross Section (XS)")
        plt.title("Ridge meta (OOF, per-row f/ENG/Z/A interactions)")
        plt.legend(); plt.tight_layout(); plt.savefig(out_png, dpi=200)

    return te

# Optional CLI for a quick local run
if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("train_csv")
    p.add_argument("target_csv")
    p.add_argument("--folds", type=int, default=5)
    p.add_argument("--label-col", default="XS")
    p.add_argument("--include-ZA",  action="store_true")
    p.add_argument("--include-ENG", action="store_true")
    p.add_argument("--eng-poly", type=int, default=1, choices=[1,2,3])
    p.add_argument("--use-log", action="store_true")
    p.add_argument("--balance-groups", action="store_true")
    p.add_argument("--plot", action="store_true")
    a = p.parse_args()
    meta_ridge_gkf_stack(
        a.train_csv, a.target_csv,
        k_folds=a.folds, label_col=a.label_col,
        include_ZA=a.include_ZA, include_ENG=a.include_ENG, eng_poly=a.eng_poly,
        use_log=a.use_log, balance_groups=a.balance_groups,
        verbose=True, plot=a.plot
    )
