#!/usr/bin/env python3
"""
iso_benchmark_meta.py  –  Ridge-CV meta-stacker benchmark for *S/M/L* groups
============================================================================

Run with one positional argument:

    python iso_benchmark_meta.py S        # or M / L  (plus Ss, Ms, …, Lp)

Outputs
-------
meta_benchmark_iso_<GROUP>.csv
"""

from __future__ import annotations
import argparse, pathlib, shutil, tempfile, re
import numpy as np, pandas as pd
from sklearn.metrics import mean_squared_error, r2_score
from mpi4py import MPI

# NEW: import Ridge4 and alias to meta_stack so the call below works
from MetaRidge5 import meta_ridge5_gkf_stack as meta_stack

# ── MPI init ────────────────────────────────────────────────────────────
comm = MPI.COMM_WORLD
rank, size = comm.Get_rank(), comm.Get_size()
if rank == 0:
    print(f"[MPI] iso_benchmark_meta running on {size} ranks", flush=True)

# ── CLI helpers ─────────────────────────────────────────────────────────
def _valid_group(tag: str) -> str:
    """
    Accept S, M, L or extended variants Ss/Ms/Ls, Sl/Ml/Ll, Sp/Mp/Lp.
    """
    tag = tag.strip()
    if re.fullmatch(r"[SML](?:[slp])?$", tag):
        return tag
    raise argparse.ArgumentTypeError(
        f"'{tag}' is not a recognised group – use S, M, L or Ss/Ms/Ls, Sl/Ml/Ll, Sp/Mp/Lp"
    )

def parse_cli() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Benchmark Ridge meta-stacker on a mass-group slice")
    p.add_argument("group", type=_valid_group,
                   help="Mass-group tag selecting AllClean4_<GROUP>.csv")
    p.add_argument("--folds", type=int, default=5,
                   help="K-folds for out-of-fold meta training (default 5)")
    p.add_argument("--repeats", type=int, default=1,
                   help="Re-fit / re-sample repeats per isotope (default 5)")
    return p.parse_args()

# ── Rank-0: resolve paths & broadcast settings ─────────────────────────
if rank == 0:
    args   = parse_cli()
    GROUP  = args.group
    KFOLDS = args.folds
    REPS   = args.repeats

    # choose data directory
    data_dir = pathlib.Path("../Batch5") if len(GROUP) == 1 \
               else pathlib.Path("../Batch6/feature_elim_outputs")

    csv_path = data_dir / f"AllClean4_{GROUP}.csv"
    out_path = pathlib.Path(f"Data/Ridge5_benchmark_iso_{GROUP}.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)   # ensure folder exists
else:
    csv_path = out_path = GROUP = KFOLDS = REPS = None

csv_path = comm.bcast(csv_path, root=0)
out_path = comm.bcast(out_path, root=0)
GROUP    = comm.bcast(GROUP,    root=0)
KFOLDS   = comm.bcast(KFOLDS,   root=0)
REPS     = comm.bcast(REPS,     root=0)

# ── Load data & slice tasks across ranks ───────────────────────────────
full      = pd.read_csv(csv_path)
iso_pairs = full[["Z", "A"]].drop_duplicates().to_numpy()
tasks     = [iso_pairs[i] for i in range(rank, len(iso_pairs), size)]

# ── Per-isotope evaluation helper ──────────────────────────────────────
def evaluate_iso(z: int, a: int) -> dict:
    """Train base models on all other isotopes, meta-stack with RidgeCV."""
    df_test  = full[(full.Z == z) & (full.A == a)].copy()
    df_train = full.drop(df_test.index).drop(columns=["XSlow", "XSupp"],
                                             errors="ignore")

    tmpdir = pathlib.Path(tempfile.mkdtemp(prefix=f"r{rank}_"))
    tr_csv, va_csv = tmpdir / "train.csv", tmpdir / "target.csv"
    df_train.to_csv(tr_csv, index=False)
    df_test.to_csv(va_csv,  index=False)

    mse_nn, mse_xgb, mse_rf, mse_meta = [], [], [], []
    r2_nn,  r2_xgb,  r2_rf,  r2_meta  = [], [], [], []

    for _ in range(REPS):
        res = meta_stack(tr_csv, va_csv,
                         k_folds=KFOLDS, verbose=False, plot=False)

        mse_nn   .append(mean_squared_error(res.actual, res.nn_pred))
        mse_xgb  .append(mean_squared_error(res.actual, res.xgb_pred))
        mse_rf   .append(mean_squared_error(res.actual, res.rf_pred))
        mse_meta .append(mean_squared_error(res.actual, res.stack_pred))

        r2_nn   .append(r2_score(res.actual, res.nn_pred))
        r2_xgb  .append(r2_score(res.actual, res.xgb_pred))
        r2_rf   .append(r2_score(res.actual, res.rf_pred))
        r2_meta .append(r2_score(res.actual, res.stack_pred))

    shutil.rmtree(tmpdir, ignore_errors=True)
    return dict(Z=z, A=a,
                mse_nn=np.mean(mse_nn),   mse_xgb=np.mean(mse_xgb),
                mse_rf=np.mean(mse_rf),   mse_meta=np.mean(mse_meta),
                r2_nn=np.mean(r2_nn),     r2_xgb=np.mean(r2_xgb),
                r2_rf=np.mean(r2_rf),     r2_meta=np.mean(r2_meta))

# ── Execute our share of isotopes ──────────────────────────────────────
local = [evaluate_iso(int(z), int(a)) for z, a in tasks]
gathered = comm.gather(local, root=0)

# ── Rank-0: combine & save CSV ─────────────────────────────────────────
if rank == 0:
    flat = [row for sub in gathered for row in sub]
    pd.DataFrame(flat).sort_values("A").to_csv(out_path, index=False)
    print(f"[DONE] Group {GROUP} → {out_path}  (rows: {len(flat)})", flush=True)
