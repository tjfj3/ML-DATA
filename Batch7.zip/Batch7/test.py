#!/usr/bin/env python3
"""
test_base_alignment_drop_multi.py

Pick 3 random isotopes (Z,A) from AllClean4_S.csv. For each isotope:
- Do a 5-fold KFold split on its rows.
- Drop XSlow & XSupp from both train and valid sets.
- Write out CSVs named train_v{1..3}_fold{1..5}.csv and valid_v{1..3}_fold{1..5}.csv.
- Check whether predict_nn, predict_xgb, predict_rf return the same number
  of rows and the same ENG ordering as the validation slice.
"""

import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import KFold

# base-model imports
from NN6  import predict_nn
from GBRT import predict_xgb
from RF6  import predict_rf

def main():
    np.random.seed(42)

    # 1) Load the "S" slice
    csv_path = Path("../Batch5/AllClean4_S.csv")
    full_df  = pd.read_csv(csv_path)

    # 2) Choose 3 random isotopes (without replacement)
    iso_pairs = full_df[["Z", "A"]].drop_duplicates().to_numpy()
    if len(iso_pairs) < 3:
        raise RuntimeError("Need at least 3 distinct isotopes in the CSV.")
    pick_idx = np.random.choice(len(iso_pairs), size=3, replace=False)
    picks = iso_pairs[pick_idx]

    out_dir = Path("KfoldTestData")
    out_dir.mkdir(parents=True, exist_ok=True)

    for v_idx, (z, a) in enumerate(picks, start=1):
        z, a = int(z), int(a)
        iso_df = full_df[(full_df.Z == z) & (full_df.A == a)].reset_index(drop=True)
        print(f"\n=== Variant v{v_idx} — Isotope Z={z}, A={a}  (n_rows={len(iso_df)}) ===")

        # 3) 5-fold KFold on that isotope
        kf = KFold(n_splits=5, shuffle=True, random_state=42)

        for fold_idx, (tr_idx, va_idx) in enumerate(kf.split(iso_df), start=1):
            tr_df = iso_df.iloc[tr_idx].reset_index(drop=True)
            va_df = iso_df.iloc[va_idx].reset_index(drop=True)

            # ─── DROP XSlow & XSupp ───────────────────────────────────────
            tr_df = tr_df.drop(columns=["XSlow","XSupp"], errors="ignore")
            va_df = va_df.drop(columns=["XSlow","XSupp"], errors="ignore")

            # 4) Write out train/validation CSVs — no subfolders, v1/v2/v3 prefix
            tr_csv = out_dir / f"train_v{v_idx}_fold{fold_idx}.csv"
            va_csv = out_dir / f"valid_v{v_idx}_fold{fold_idx}.csv"
            tr_df.to_csv(tr_csv, index=False)
            va_df.to_csv(va_csv, index=False)

            # 5) Run base-model predictors
            nn_df  = predict_nn (tr_csv, va_csv)
            xgb_df = predict_xgb(tr_csv, va_csv)
            rf_df  = predict_rf (tr_csv, va_csv)

            # 6) Report row-counts
            n_va   = len(va_df)
            n_nn   = len(nn_df)
            n_xgb  = len(xgb_df)
            n_rf   = len(rf_df)
            print(f"--- Fold {fold_idx} ---")
            print(f"Validation rows : {n_va}")
            print(f" nn output rows : {n_nn}")
            print(f" xgb output rows: {n_xgb}")
            print(f" rf output rows : {n_rf}")

            # 7) Compare ENG ordering
            eng_va  = va_df["ERG"].to_numpy()
            eng_nn  = nn_df ["ENG"].to_numpy()
            eng_xgb = xgb_df["ENG"].to_numpy()
            eng_rf  = rf_df ["ENG"].to_numpy()

            print(f" nn order match?  {np.array_equal(eng_va, eng_nn)}")
            print(f" xgb order match? {np.array_equal(eng_va, eng_xgb)}")
            print(f" rf order match?  {np.array_equal(eng_va, eng_rf)}")

if __name__ == "__main__":
    main()
