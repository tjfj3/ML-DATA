#!/usr/bin/env python3
"""
MPI LIME feature elimination for NN6 + Bayesian optimisation
------------------------------------------------------------
* Re-optimises a Keras NN6 network (bayes_opt_nn) after each feature drop.
* Uses LIME TabularExplainer mean |weight| on the validation fold.
* Logs every repeat's MSE to OUTDIR/repeats_mse.csv.
* Checkpoints after every drop so you can resume across runs.

Launch:
    srun --mpi=pmix_v3 python NN6_LIME_feature_elim.py
"""

# ─────────── Keras 3 ↔ tf.keras shim (safe no-op if TF already present) ───────────
import sys, types, importlib
if "tensorflow.keras" not in sys.modules:
    try:
        keras_mod = importlib.import_module("keras")  # standalone Keras 3
        tf_mod = sys.modules.get("tensorflow", types.ModuleType("tensorflow"))
        tf_mod.keras = keras_mod
        sys.modules["tensorflow"] = tf_mod
        sys.modules["tensorflow.keras"] = keras_mod
    except Exception:
        pass

# ─────────────────────────────────────────────────────────────
# Std lib
# ─────────────────────────────────────────────────────────────
from pathlib import Path
import json
from typing import List, Dict, Any

# ─────────────────────────────────────────────────────────────
# Third-party
# ─────────────────────────────────────────────────────────────
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error

import tensorflow as tf
from tensorflow import keras
from mpi4py import MPI
from lime.lime_tabular import LimeTabularExplainer

# ─────────────────────────────────────────────────────────────
# Local imports (Batch6 + Batch8)
# ─────────────────────────────────────────────────────────────
from NN6   import _build_model as _build_nn6_base
from NNbay import bayes_opt_nn

# ─────────────────────────────────────────────────────────────
# MPI setup
# ─────────────────────────────────────────────────────────────
comm  = MPI.COMM_WORLD
rank  = comm.Get_rank()
size  = comm.Get_size()

# ─────────────────────────────────────────────────────────────
# Hard-coded constants
# ─────────────────────────────────────────────────────────────
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"

MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 60

SEED                = 42
REPEATS             = 5
BAYES_EVALS         = 30

LIME_INSTANCES      = 128
LIME_SAMPLES        = 2000

CHECKPOINT_PATH     = Path("NN6_LIME_feature_elim.ckpt.json")
OUTDIR              = Path("NN6_LIME_feature_elim_out_pass1")

# ─────────────────────────────────────────────────────────────
# Helper: build NN6 with custom params
# ─────────────────────────────────────────────────────────────
def _build_nn6(input_dim: int, params: Dict[str, Any], *, seed: int):
    tf.random.set_seed(seed)
    reg = keras.regularizers.l2(params["l2"])
    layers = [keras.layers.Input(shape=(input_dim,))]
    for _ in range(int(params["n_layers"])):
        layers.append(
            keras.layers.Dense(
                int(params["units"]),
                activation=params["activation"],
                kernel_regularizer=reg,
            )
        )
        if params["dropout"] > 0:
            layers.append(keras.layers.Dropout(params["dropout"]))
    layers.append(keras.layers.Dense(1))
    model = keras.Sequential(layers)
    model.compile(
        optimizer=keras.optimizers.Adam(params["learning_rate"]),
        loss="mse",
    )
    return model

# ─────────────────────────────────────────────────────────────
# LIME helper
# ─────────────────────────────────────────────────────────────
def _lime_mean_abs_importance_nn(
    model: keras.Model,
    scaler: StandardScaler,
    X_train_bg: pd.DataFrame,
    X_val: pd.DataFrame,
    *,
    feature_names: List[str],
    n_instances: int,
    num_samples: int,
    seed: int,
) -> np.ndarray:
    """Mean |LIME weight| per feature. Works on SCALED space (to match the model)."""
    rng = np.random.default_rng(seed)
    n_features = X_val.shape[1]

    explainer = LimeTabularExplainer(
        training_data=scaler.transform(X_train_bg),
        feature_names=list(feature_names),
        mode="regression",
        discretize_continuous=True,
        sample_around_instance=True,
        random_state=seed,
        verbose=False,
    )

    n_instances = min(n_instances, len(X_val))
    sel_idx = rng.choice(len(X_val), size=n_instances, replace=False)
    agg = np.zeros(n_features, dtype=float)

    def predict_fn(x):
        # x is already scaled (we pass scaled rows below)
        return model.predict(x, verbose=0).reshape(-1)

    for i in sel_idx:
        row_scaled = scaler.transform(X_val.iloc[[i]])  # (1, n_features)
        exp = explainer.explain_instance(
            data_row=row_scaled.ravel(),
            predict_fn=predict_fn,
            num_features=n_features,   # ask for weights for all features
            num_samples=num_samples,
        )
        # Safer for regression: take the first (and only) entry
        local_map = next(iter(exp.local_exp.values()))  # list[(j, weight)]
        for j, w in local_map:
            agg[j] += abs(w)

    return agg / max(1, n_instances)

# ─────────────────────────────────────────────────────────────
# Checkpoint utils
# ─────────────────────────────────────────────────────────────
def _save_ckpt(path: Path, state: Dict[str, Any]):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(state, indent=2))
    tmp.replace(path)

def _load_ckpt(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text())

# ─────────────────────────────────────────────────────────────
# Main elimination routine
# ─────────────────────────────────────────────────────────────
def mpi_feature_elim_nn_lime(
    X_df: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features: int,
    repeats: int,
    seed: int,
    bayes_evals: int,
    lime_instances: int,
    lime_samples: int,
    max_drops: int,
    checkpoint: Path,
    verbose: bool = True,
):
    # Prepare output dir early (for per-repeat logging)
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # ---------- init / resume ----------
    if rank == 0:
        if checkpoint.exists():
            ckpt = _load_ckpt(checkpoint)
            cols, best_feats = ckpt["cols"], ckpt["best_features"]
            best_mse, history, total = ckpt["best_mse"], ckpt["history"], ckpt["total"]
            drops_this = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Resume] {len(cols)} features remain.")
        else:
            cols = list(X_df.columns)
            best_feats = cols.copy()
            best_mse = float("inf")
            history: List[Dict[str, Any]] = []
            total = len(cols)
            drops_this = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Start] Fresh run with {len(cols)} features.")
    else:
        cols = best_feats = history = best_mse = total = drops_this = None

    cols, best_feats, best_mse, total, drops_this = comm.bcast(
        (cols, best_feats, best_mse, total, drops_this), root=0
    )

    while len(cols) > min_features and drops_this < max_drops:
        # ---------- hyper-opt ----------
        if rank == 0 and verbose:
            print(f"\n[Iter] Optimising on {len(cols)} features…", flush=True)
            best_params = bayes_opt_nn(X_df[cols], y, max_evals=bayes_evals, random_state=seed)
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # ---------- distribute repeats ----------
        seeds = [seed + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # Fresh split + fresh model per repeat
            X_tr, X_val, y_tr, y_val = train_test_split(
                X_df[cols], y, test_size=0.2, random_state=s
            )

            scaler = StandardScaler().fit(X_tr)
            X_tr_s = scaler.transform(X_tr)
            X_val_s = scaler.transform(X_val)

            tf.keras.backend.clear_session()
            model = _build_nn6(len(cols), best_params, seed=s)
            model.fit(
                X_tr_s, y_tr,
                epochs=best_params["epochs"],
                batch_size=best_params["batch_size"],
                verbose=0,
            )

            # MSE for this repeat
            preds = model.predict(X_val_s, verbose=0).flatten()
            local_mses.append(mean_squared_error(y_val, preds))

            # LIME importance (operate in scaled space to match the model)
            imp = _lime_mean_abs_importance_nn(
                model, scaler, X_tr, X_val,
                feature_names=cols,
                n_instances=lime_instances,
                num_samples=lime_samples,
                seed=s,
            )
            local_imps.append(imp)

        gathered_mses  = comm.gather(local_mses, root=0)
        gathered_imps  = comm.gather(local_imps, root=0)
        gathered_seeds = comm.gather(my_seeds,   root=0)

        if rank == 0:
            mses      = [m for sub in gathered_mses for m in sub]
            imps      = [v for sub in gathered_imps for v in sub]
            seeds_all = [sd for sub in gathered_seeds for sd in sub]
            if len(mses) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # —— Log every repeat's MSE
            iter_id = len(history) + 1
            n_feat  = len(cols)
            mse_csv = OUTDIR / "repeats_mse.csv"
            need_header = not mse_csv.exists()
            with mse_csv.open("a") as f:
                if need_header:
                    f.write("iter,n_features,seed,mse\n")
                for sd, m in zip(seeds_all, mses):
                    f.write(f"{iter_id},{n_feat},{sd},{m}\n")

            # Averages for decision
            avg_mse = float(np.mean(mses))
            avg_imp = np.mean(imps, axis=0)

            history.append(
                dict(n_features=len(cols), mse=avg_mse,
                     kept_cols=cols.copy(), best_params=best_params.copy())
            )

            if avg_mse < best_mse:
                best_mse = avg_mse
                best_feats = cols.copy()

            # drop worst
            if len(cols) > min_features:
                worst_idx = int(np.argmin(avg_imp))
                dropped = cols.pop(worst_idx)
                drops_this += 1
                cont = drops_this < max_drops and len(cols) > min_features
                if verbose:
                    kept = len(cols)
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({total-kept}/{total} removed)  "
                          f"[{drops_this}/{max_drops} this pass]", flush=True)
            else:
                cont = False

            _save_ckpt(
                checkpoint,
                dict(cols=cols, best_mse=best_mse,
                     best_features=best_feats, history=history, total=total)
            )
            state = dict(cols=cols, best_mse=best_mse,
                         best_features=best_feats, cont=cont)
        else:
            state = None

        state = comm.bcast(state, root=0)
        cols, best_mse, best_feats = state["cols"], state["best_mse"], state["best_features"]
        if not state["cont"]:
            break

    # ---------- final I/O ----------
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_feats, name="kept_columns").to_csv(OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols, name="current_cols_after_pass").to_csv(OUTDIR / "current_cols_after_pass.csv", index=False)
        X_df[best_feats].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] Pass finished with {len(cols)} features. Best MSE so far: {best_mse:.6e}")

# ─────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────
def main():
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}")
    df = pd.read_csv(CSV_PATH)
    if TARGET_COL not in df.columns:
        raise SystemExit(f"Dataset missing column '{TARGET_COL}'")
    # Drop target + leak columns
    X_df = df.drop(columns=[TARGET_COL, "XSlow", "XSupp", "anity", "MT"], errors="ignore")
    y    = df[TARGET_COL].values

    mpi_feature_elim_nn_lime(
        X_df, y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        seed=SEED,
        bayes_evals=BAYES_EVALS,
        lime_instances=LIME_INSTANCES,
        lime_samples=LIME_SAMPLES,
        max_drops=MAX_DROPS_THIS_PASS,
        checkpoint=CHECKPOINT_PATH,
        verbose=(rank == 0),
    )

if __name__ == "__main__":
    main()
