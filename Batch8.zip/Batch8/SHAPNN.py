#!/usr/bin/env python3
"""
MPI SHAP feature elimination for NN6 + Bayesian optimisation
------------------------------------------------------------
* Re-optimises a Keras NN6 model (bayes_opt_nn) after each feature drop.
* Uses SHAP GradientExplainer to compute mean |SHAP| on the validation fold.
* Checkpoints and outputs are written locally.

Launch:
    srun --mpi=pmix_v3 python NN6_SHAP_feature_elim.py
"""

# ─────────────────────────────────────────────────────────────
# 1)  Compatibility shim  – must be the FIRST third-party code
# ─────────────────────────────────────────────────────────────
import sys, types, importlib
if "tensorflow.keras" not in sys.modules:
    keras_mod = importlib.import_module("keras")                # Keras 3
    tf_mod = sys.modules.get("tensorflow", types.ModuleType("tensorflow"))
    tf_mod.keras = keras_mod
    sys.modules["tensorflow"] = tf_mod
    sys.modules["tensorflow.keras"] = keras_mod

# ─────────────────────────────────────────────────────────────
# Standard libs
# ─────────────────────────────────────────────────────────────
from pathlib import Path
import json
from typing import List, Dict, Any

# ─────────────────────────────────────────────────────────────
# Third-party
# ─────────────────────────────────────────────────────────────
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error
import tensorflow as tf
from tensorflow import keras

try:
    import shap
except Exception as e:
    raise SystemExit(
        "[ERROR] Could not import SHAP. Install with:\n"
        "  conda install -c conda-forge shap   (or)   pip install shap\n"
        f"Import error: {e}"
    )

try:
    from mpi4py import MPI
except ImportError:
    raise SystemExit("[ERROR] mpi4py is not installed in this environment.")

# ─────────────────────────────────────────────────────────────
# MPI setup
# ─────────────────────────────────────────────────────────────
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# ─────────────────────────────────────────────────────────────
# Local imports
# ─────────────────────────────────────────────────────────────
from NN6   import _build_model as _build_nn6_base   # not used directly; kept for reference
from NNbay import bayes_opt_nn

# ─────────────────────────────────────────────────────────────
# Hard-coded constants (edit between passes)
# ─────────────────────────────────────────────────────────────
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"

MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 100

SEED                = 42
REPEATS             = 5
BAYES_EVALS         = 30
SHAP_MAX_ROWS       = 1024

CHECKPOINT_PATH     = Path("NN6_SHAP_feature_elim.ckpt.json")
OUTDIR              = Path("NN6_SHAP_feature_elim_out_pass4")

# ─────────────────────────────────────────────────────────────
# Helper: build NN6 with custom hyper-parameters
# ─────────────────────────────────────────────────────────────
def _build_nn6(input_dim: int, params: Dict[str, Any], *, seed: int) -> keras.Model:
    tf.random.set_seed(seed)
    reg = keras.regularizers.l2(params["l2"])
    layers = [keras.layers.Input(shape=(input_dim,))]
    for _ in range(int(params["n_layers"])):
        layers.append(
            keras.layers.Dense(
                int(params["units"]),
                activation=params["activation"],
                kernel_regularizer=reg,
            )
        )
        if params["dropout"] > 0:
            layers.append(keras.layers.Dropout(params["dropout"]))
    layers.append(keras.layers.Dense(1))
    model = keras.Sequential(layers)
    model.compile(optimizer=keras.optimizers.Adam(params["learning_rate"]), loss="mse")
    return model

# ─────────────────────────────────────────────────────────────
# SHAP helper (GradientExplainer for Keras)
# ─────────────────────────────────────────────────────────────
def _mean_abs_shap_keras(
    model: keras.Model,
    X_val: np.ndarray,
    *,
    max_rows: int,
    seed: int,
) -> np.ndarray:
    """Mean |SHAP| per feature for a Keras regression model."""
    n_samples, n_features = X_val.shape
    if n_samples > max_rows:
        rng = np.random.default_rng(seed)
        idx = rng.choice(n_samples, size=max_rows, replace=False)
        X_use = X_val[idx]
    else:
        X_use = X_val

    # Background: small random subset
    background = shap.sample(X_use, 100, random_state=seed)
    explainer = shap.GradientExplainer(model, background)
    sv = explainer.shap_values(X_use, nsamples=min(128, len(X_use)))[0]  # (n_samples, n_features)
    return np.mean(np.abs(sv), axis=0)

# ─────────────────────────────────────────────────────────────
# Checkpoint utilities
# ─────────────────────────────────────────────────────────────
def _save_ckpt(path: Path, state: Dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w") as f:
        json.dump(state, f, indent=2)
    tmp.replace(path)

def _load_ckpt(path: Path) -> Dict[str, Any]:
    with path.open("r") as f:
        return json.load(f)

# ─────────────────────────────────────────────────────────────
# Main elimination routine
# ─────────────────────────────────────────────────────────────
def mpi_feature_elim_nn6_shap(
    X_df: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features: int,
    repeats: int,
    random_state: int,
    bayes_max_evals: int,
    shap_max_rows: int,
    max_drops: int,
    checkpoint_path: Path,
    verbose_root: bool = True,
):
    # Ensure output dir exists (for per-repeat MSE logging)
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # Load or init checkpoint (rank 0)
    if rank == 0:
        if checkpoint_path.exists():
            ckpt = _load_ckpt(checkpoint_path)
            cols = ckpt["cols"]
            best_features = ckpt["best_features"]
            best_mse = ckpt["best_mse"]
            history = ckpt["history"]
            total = ckpt.get("total", len(cols) + len(history))
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Resume] Loaded checkpoint with {len(cols)} remaining features.", flush=True)
        else:
            cols = list(X_df.columns)
            best_features = cols.copy()
            best_mse = float("inf")
            history: List[Dict[str, Any]] = []
            total = len(cols)
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Start] Fresh run with {len(cols)} features.", flush=True)
    else:
        cols = best_features = history = best_mse = total = drops_this_job = None

    # Broadcast initial state
    cols           = comm.bcast(cols, root=0)
    best_features  = comm.bcast(best_features, root=0)
    best_mse       = comm.bcast(best_mse, root=0)
    total          = comm.bcast(total, root=0)
    drops_this_job = comm.bcast(drops_this_job, root=0)

    # Main loop
    while len(cols) > min_features and drops_this_job < max_drops:
        # Hyperopt on current subset (rank 0)
        if rank == 0 and verbose_root:
            print(f"\n[Iter] Optimising on {len(cols)} features…", flush=True)
            best_params = bayes_opt_nn(X_df[cols], y, max_evals=bayes_max_evals, random_state=random_state)
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # Distribute repeats across ranks
        seeds = [random_state + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # Fresh split + fresh model per repeat
            X_tr, X_val, y_tr, y_val = train_test_split(X_df[cols], y, test_size=0.2, random_state=s)

            # Standardise
            scaler = StandardScaler().fit(X_tr)
            X_tr_s  = scaler.transform(X_tr)
            X_val_s = scaler.transform(X_val)

            # Build & train NN
            tf.keras.backend.clear_session()
            model = _build_nn6(len(cols), best_params, seed=s)
            model.fit(
                X_tr_s, y_tr,
                epochs=best_params["epochs"],
                batch_size=best_params["batch_size"],
                verbose=0,
            )

            # MSE on validation
            preds = model.predict(X_val_s, verbose=0).flatten()
            local_mses.append(mean_squared_error(y_val, preds))

            # SHAP mean-|val| for elimination signal
            imp = _mean_abs_shap_keras(model, X_val_s, max_rows=shap_max_rows, seed=s)
            local_imps.append(imp)

        # Gather to rank 0
        gathered_mses  = comm.gather(local_mses, root=0)
        gathered_imps  = comm.gather(local_imps, root=0)
        gathered_seeds = comm.gather(my_seeds,   root=0)

        if rank == 0:
            mses_flat  = [m for sub in gathered_mses for m in sub]
            imps_flat  = [v for sub in gathered_imps for v in sub]
            seeds_flat = [s for sub in gathered_seeds for s in sub]
            if len(mses_flat) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # —— Log every repeat's MSE
            iter_id = len(history) + 1
            n_feat  = len(cols)
            mse_csv = OUTDIR / "repeats_mse.csv"
            need_header = not mse_csv.exists()
            with mse_csv.open("a") as f:
                if need_header:
                    f.write("iter,n_features,seed,mse\n")
                for s, m in zip(seeds_flat, mses_flat):
                    f.write(f"{iter_id},{n_feat},{s},{m}\n")

            # Averages for decision
            avg_mse = float(np.mean(mses_flat))
            avg_imp = np.mean(imps_flat, axis=0)

            history.append({
                "n_features": len(cols),
                "mse": avg_mse,
                "kept_cols": cols.copy(),
                "best_params": best_params.copy(),
            })

            if avg_mse < best_mse:
                best_mse = avg_mse
                best_features = cols.copy()

            # Drop worst feature by SHAP
            if len(cols) <= min_features:
                cont = False
            else:
                worst_idx = int(np.argmin(avg_imp))
                dropped = cols.pop(worst_idx)
                drops_this_job += 1
                cont = (drops_this_job < max_drops) and (len(cols) > min_features)
                if verbose_root:
                    kept = len(cols)
                    removed = total - kept
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({removed}/{total} removed → {kept}/{total} remain)  "
                          f"[drops this pass: {drops_this_job}/{max_drops}]",
                          flush=True)

            # Checkpoint
            _save_ckpt(CHECKPOINT_PATH, {
                "cols": cols,
                "best_mse": best_mse,
                "best_features": best_features,
                "history": history,
                "total": total,
            })

            state = {"cols": cols, "best_mse": best_mse, "best_features": best_features, "cont": cont}
        else:
            state = None

        # Broadcast next state
        state = comm.bcast(state, root=0)
        cols = state["cols"]
        best_mse = state["best_mse"]
        best_features = state["best_features"]
        if not state["cont"]:
            break

    # Final outputs (rank 0)
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_features, name="kept_columns").to_csv(OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols,         name="current_cols_after_pass").to_csv(OUTDIR / "current_cols_after_pass.csv", index=False)
        X_df[best_features].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] Pass finished with {len(cols)} features remaining. Best MSE so far: {best_mse:.6e}")

# ─────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────
def main():
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}", flush=True)
    df = pd.read_csv(CSV_PATH)
    if TARGET_COL not in df.columns:
        raise SystemExit(f"Target column '{TARGET_COL}' not found in dataset.")
    # Drop target + known leak/aux columns right here
    X_df = df.drop(columns=[TARGET_COL, "XSlow", "XSupp", "anity", "MT"], errors="ignore")
    y = df[TARGET_COL].values

    mpi_feature_elim_nn6_shap(
        X_df,
        y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        random_state=SEED,
        bayes_max_evals=BAYES_EVALS,
        shap_max_rows=SHAP_MAX_ROWS,
        max_drops=MAX_DROPS_THIS_PASS,
        checkpoint_path=CHECKPOINT_PATH,
        verbose_root=(rank == 0),
    )

if __name__ == "__main__":
    main()
