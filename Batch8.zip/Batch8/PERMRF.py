#!/usr/bin/env python3
"""
MPI Perm-Importance feature elimination for Random-Forest (RF6)
---------------------------------------------------------------
* Re-tunes with bayes_opt_rf after each drop.
* Forests are always created via RF6._build_rf() then overwritten with tuned params.
* Uses sklearn permutation_importance on a validation fold.
* Logs every repeat's MSE to OUTDIR/repeats_mse.csv.
* Checkpoints after each drop so the run can be resumed.

Launch:
    srun --mpi=pmix_v3 python RF_PERM_feature_elim.py
"""

# ─────────── std-lib ───────────
from pathlib import Path
import json
from typing import List, Dict, Any

# ───────── third-party ─────────
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.inspection import permutation_importance
from mpi4py import MPI

# ────────── local code ─────────
from RF6   import _build_rf                     # RF factory
from RFbay import bayes_opt_rf                  # optimiser

# ─────────── MPI init ──────────
comm  = MPI.COMM_WORLD
rank  = comm.Get_rank()
size  = comm.Get_size()

# ───────── user constants ──────
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"

MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 100

SEED                = 42
REPEATS             = 5
BAYES_EVALS         = 30

PI_REPEATS          = 5          # permutations per feature
PI_MAX_VAL_ROWS     = 2000       # cap validation rows

CHECKPOINT_PATH     = Path("RF_PERM_feature_elim.ckpt.json")
OUTDIR              = Path("RF_PERM_feature_elim_out_pass1")

# Limit threads per MPI rank (avoid oversubscription)
RF_N_JOBS_PER_RANK  = 1

# ───────── helpers ─────────────
def _downsample(X_val, y_val, max_rows, seed):
    if len(X_val) <= max_rows:
        return X_val, y_val
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(X_val), size=max_rows, replace=False)
    return X_val.iloc[idx], y_val[idx]

def _save_ckpt(p: Path, s: Dict[str, Any]):
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(s, indent=2))
    tmp.replace(p)

def _load_ckpt(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text())

# ───────── main routine ────────
def mpi_feature_elim_rf_perm(
    X_df: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features, repeats, seed,
    bayes_evals, pi_repeats, pi_max_rows,
    max_drops, ckpt_path: Path, verbose=True
):

    # ensure OUTDIR exists for per-repeat logging
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # ----- init / resume -----
    if rank == 0:
        if ckpt_path.exists():
            ck = _load_ckpt(ckpt_path)
            cols, best_feats = ck["cols"], ck["best_features"]
            best_mse, history, total = ck["best_mse"], ck["history"], ck["total"]
            drops = 0
            print(f"[MPI] Ranks: {size}  —  Resume with {len(cols)} features.")
        else:
            cols = list(X_df.columns)
            best_feats = cols.copy()
            best_mse = float("inf")
            history: List[Dict[str, Any]] = []
            total = len(cols)
            drops = 0
            print(f"[MPI] Ranks: {size}  —  Fresh run with {len(cols)} features.")
    else:
        cols = best_feats = history = best_mse = total = drops = None

    cols, best_feats, best_mse, total, drops = comm.bcast(
        (cols, best_feats, best_mse, total, drops), root=0)

    while len(cols) > min_features and drops < max_drops:
        # ----- hyper-opt on current subset -----
        if rank == 0 and verbose:
            print(f"\n[Iter] Optimising on {len(cols)} features…", flush=True)
            best_params = bayes_opt_rf(
                X_df[cols], y, max_evals=bayes_evals, random_state=seed
            )
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # ----- distribute repeats -----
        seeds = [seed + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # fresh split + fresh forest per repeat
            X_tr, X_val, y_tr, y_val = train_test_split(
                X_df[cols], y, test_size=0.2, random_state=s
            )

            model = (
                _build_rf()
                .set_params(**best_params, random_state=s, n_jobs=RF_N_JOBS_PER_RANK)
                .fit(X_tr, y_tr)
            )

            preds = model.predict(X_val)
            local_mses.append(mean_squared_error(y_val, preds))

            Xv_use, yv_use = _downsample(X_val, y_val, pi_max_rows, s)
            pi = permutation_importance(
                model, Xv_use, yv_use,
                scoring="neg_mean_squared_error",
                n_repeats=pi_repeats, random_state=s, n_jobs=1
            )
            local_imps.append(pi.importances_mean)

        gathered_mses  = comm.gather(local_mses, root=0)
        gathered_imps  = comm.gather(local_imps, root=0)
        gathered_seeds = comm.gather(my_seeds,   root=0)

        if rank == 0:
            mses      = [m  for sub in gathered_mses  for m  in sub]
            imps      = [v  for sub in gathered_imps  for v  in sub]
            seeds_all = [sd for sub in gathered_seeds for sd in sub]
            if len(mses) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # ---- log every repeat's MSE
            iter_id  = len(history) + 1
            n_feat   = len(cols)
            mse_csv  = OUTDIR / "repeats_mse.csv"
            need_hdr = not mse_csv.exists()
            with mse_csv.open("a") as f:
                if need_hdr:
                    f.write("iter,n_features,seed,mse\n")
                for sd, m in zip(seeds_all, mses):
                    f.write(f"{iter_id},{n_feat},{sd},{m}\n")

            # Averages for decision
            avg_mse = float(np.mean(mses))
            avg_imp = np.mean(imps, axis=0)

            history.append(dict(
                n_features=len(cols), mse=avg_mse,
                kept_cols=cols.copy(), best_params=best_params.copy())
            )

            if avg_mse < best_mse:
                best_mse   = avg_mse
                best_feats = cols.copy()

            # drop worst feature
            if len(cols) > min_features:
                worst = int(np.argmin(avg_imp))
                dropped = cols.pop(worst)
                drops += 1
                cont = drops < max_drops and len(cols) > min_features
                if verbose:
                    kept = len(cols)
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({total-kept}/{total} removed) "
                          f"[{drops}/{max_drops} this pass]")
            else:
                cont = False

            _save_ckpt(ckpt_path, dict(
                cols=cols, best_mse=best_mse,
                best_features=best_feats, history=history, total=total)
            )
            state = dict(cols=cols, best_mse=best_mse,
                         best_features=best_feats, cont=cont)
        else:
            state = None

        state = comm.bcast(state, root=0)
        cols, best_mse, best_feats = state["cols"], state["best_mse"], state["best_features"]
        if not state["cont"]:
            break

    # ----- final I/O -----
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_feats, name="kept_columns").to_csv(
            OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols, name="current_cols_after_pass").to_csv(
            OUTDIR / "current_cols_after_pass.csv", index=False)
        X_df[best_feats].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] Pass finished with {len(cols)} features. "
              f"Best MSE so far: {best_mse:.6e}")

# ───────── entry point ────────
def main():
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}")
    df = pd.read_csv(CSV_PATH)
    if TARGET_COL not in df.columns:
        raise SystemExit(f"Dataset missing column '{TARGET_COL}'")
    # Drop target + leak columns
    X_df = df.drop(columns=[TARGET_COL, "XSlow", "XSupp", "anity", "MT"], errors="ignore")
    y    = df[TARGET_COL].values

    mpi_feature_elim_rf_perm(
        X_df, y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        seed=SEED,
        bayes_evals=BAYES_EVALS,
        pi_repeats=PI_REPEATS,
        pi_max_rows=PI_MAX_VAL_ROWS,
        max_drops=MAX_DROPS_THIS_PASS,
        ckpt_path=CHECKPOINT_PATH,
        verbose=(rank == 0),
    )

if __name__ == "__main__":
    main()
