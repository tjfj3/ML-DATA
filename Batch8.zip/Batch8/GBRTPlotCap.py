#!/usr/bin/env python3
"""
Plot MSE vs number of features from feature_elim_history.csv files.

Hard-code the CSV paths in CSV_FILES, then run:
    python plot_mse_vs_features.py
A PNG is saved to OUTPUT_PNG.
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# ───────────────────────────────────────────────────────────────────────
# EDIT THESE PATHS
CSV_FILES = [
    "LIME_feature_elim_out_pass1/feature_elim_history.csv",   # LIME
    "SHAP_feature_elim_out_pass1/feature_elim_history.csv",   # SHAP
    "pi_feature_elim_out_pass1/feature_elim_history.csv",     # PERM
]
OUTPUT_PNG = Path("Feature_Elim_GBRT_V3Cap.png")
TITLE = "XGBoost: MSE vs No of Features (LIME · SHAP · PERM)"
INVERT_X = True       # show 64→…→3 left→right

MIN_FEATURES_TO_PLOT = 6       # NEW  – drop rows with < 6 features
# ───────────────────────────────────────────────────────────────────────


def load_history(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)[["n_features", "mse"]].copy()
    df["n_features"] = pd.to_numeric(df["n_features"], errors="coerce")
    df["mse"]   = pd.to_numeric(df["mse"],   errors="coerce")
    df = df.dropna(subset=["n_features", "mse"])
    # keep last entry if n_features duplicated
    df = df.sort_values(["n_features"]).drop_duplicates("n_features", keep="last")

    # ─── TRIM OFF SMALL-FEATURE OUTLIERS ───────────────────────────────
    df = df[df["n_features"] >= MIN_FEATURES_TO_PLOT]          # NEW
    # ──────────────────────────────────────────────────────────────────

    return df.sort_values("n_features")


def main() -> None:
    if not CSV_FILES:
        raise SystemExit("Please add at least one CSV path to CSV_FILES.")

    plt.figure(figsize=(8, 5))
    plotted = 0

    for path in CSV_FILES:
        p = Path(path)
        if not p.exists():
            print(f"[WARN] Missing file: {p}")
            continue
        df = load_history(p)
        if df.empty:                         # NEW – skip if everything was cut
            print(f"[WARN] No rows left after trimming for {p}")
            continue
        label = p.parent.name or p.name
        plt.plot(df["n_features"], df["mse"],
                 marker="o", linewidth=1.5, label=label)
        plotted += 1

    if plotted == 0:
        raise SystemExit("No valid CSV files found – nothing to plot.")

    plt.xlabel("Number of features")
    plt.ylabel("MSE")
    plt.title(TITLE)
    plt.grid(True, linestyle="--", alpha=0.4)
    if INVERT_X:
        plt.gca().invert_xaxis()
    if plotted > 1:
        plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_PNG, dpi=150)
    print(f"Saved plot → {OUTPUT_PNG.resolve()}")


if __name__ == "__main__":
    main()
