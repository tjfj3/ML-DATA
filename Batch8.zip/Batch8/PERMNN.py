#!/usr/bin/env python3
"""
MPI Perm-Importance feature elimination for NN6 + Bayesian optimisation
-----------------------------------------------------------------------
* Re-optimises Keras NN6 hyper-parameters (bayes_opt_nn) after every drop.
* Uses scikit-learn permutation_importance on a validation fold.
* Logs every repeat's MSE to OUTDIR/repeats_mse.csv.
* Checkpoints after each drop so you can resume across HPC runs.

Launch:
    srun --mpi=pmix_v3 python NN6_PERM_feature_elim.py
"""

# ───────────────────────── Keras 3 ↔ tf.keras shim (must come first) ─────────────────────────
import sys, types, importlib
if "tensorflow.keras" not in sys.modules:
    try:
        keras_mod = importlib.import_module("keras")  # standalone Keras 3
        tf_mod = sys.modules.get("tensorflow", types.ModuleType("tensorflow"))
        tf_mod.keras = keras_mod
        sys.modules["tensorflow"] = tf_mod
        sys.modules["tensorflow.keras"] = keras_mod
    except Exception:
        pass  # if TensorFlow is already present, nothing to do

# ───────────────────────────── std-lib ──────────────────────────────
from pathlib import Path
import json
from typing import List, Dict, Any

# ─────────────────────────── third-party ────────────────────────────
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.inspection import permutation_importance
from sklearn.preprocessing import StandardScaler
from sklearn.base import BaseEstimator, RegressorMixin

import tensorflow as tf
from tensorflow import keras
from mpi4py import MPI

# ───────────────────────────── local ────────────────────────────────
from NN6   import _build_model as _build_nn6_base   # original architecture (kept for reference)
from NNbay import bayes_opt_nn                      # Bayesian optimiser for NN6

# ─────────────────────────── MPI setup ─────────────────────────────
comm  = MPI.COMM_WORLD
rank  = comm.Get_rank()
size  = comm.Get_size()

# ─────────────────────────── constants ─────────────────────────────
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"

MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 60

SEED                = 42
REPEATS             = 5
BAYES_EVALS         = 30

PI_REPEATS          = 5          # permutations per feature
PI_MAX_VAL_ROWS     = 2000       # cap validation rows for speed

CHECKPOINT_PATH     = Path("NN6_PERM_feature_elim.ckpt.json")
OUTDIR              = Path("NN6_PERM_feature_elim_out_pass1")

# ───────────────────── helper: build NN6 with params ───────────────
def _build_nn6(input_dim: int, params: Dict[str, Any], *, seed: int):
    tf.random.set_seed(seed)
    reg = keras.regularizers.l2(params["l2"])
    layers = [keras.layers.Input(shape=(input_dim,))]
    for _ in range(int(params["n_layers"])):
        layers.append(
            keras.layers.Dense(
                int(params["units"]),
                activation=params["activation"],
                kernel_regularizer=reg,
            )
        )
        if params["dropout"] > 0:
            layers.append(keras.layers.Dropout(params["dropout"]))
    layers.append(keras.layers.Dense(1))
    model = keras.Sequential(layers)
    model.compile(optimizer=keras.optimizers.Adam(params["learning_rate"]), loss="mse")
    return model

# ───────── wrapper so permutation_importance can call predict() on unscaled X ─────────
class ScaledModel(BaseEstimator, RegressorMixin):
    """
    sklearn-compatible wrapper: (scaler → Keras model).
    permutation_importance will call predict(X) repeatedly; we scale inside.
    """
    def __init__(self, model: keras.Model, scaler: StandardScaler):
        self.model  = model
        self.scaler = scaler

    # clone() API (not strictly needed by permutation_importance, but safe)
    def get_params(self, deep=False): return {}
    def set_params(self, **params):   return self
    def fit(self, X, y=None):         return self

    def predict(self, X):
        Xs = self.scaler.transform(X)
        return self.model.predict(Xs, verbose=0).flatten()

# ────────────────────── misc helpers ───────────────────────────────
def _downsample(X_val, y_val, max_rows, seed):
    if len(X_val) <= max_rows:
        return X_val, y_val
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(X_val), size=max_rows, replace=False)
    return X_val.iloc[idx], y_val[idx]

def _save_ckpt(p: Path, s: Dict[str, Any]):
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(s, indent=2))
    tmp.replace(p)

def _load_ckpt(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text())

# ────────────────────── main elimination loop ──────────────────────
def mpi_feature_elim_nn_perm(
    X_df: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features, repeats, seed,
    bayes_evals, pi_repeats, pi_max_rows,
    max_drops, ckpt_path: Path, verbose=True,
):
    # Ensure OUTDIR exists early (for per-repeat logging)
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # ----- init / resume -----
    if rank == 0:
        if ckpt_path.exists():
            ck = _load_ckpt(ckpt_path)
            cols        = ck["cols"]
            best_feats  = ck["best_features"]
            best_mse    = ck["best_mse"]
            history     = ck["history"]
            total       = ck.get("total", len(cols) + len(history))
            drops       = 0
            print(f"[MPI] Ranks: {size}  —  Resume with {len(cols)} features.", flush=True)
        else:
            cols        = list(X_df.columns)
            best_feats  = cols.copy()
            best_mse    = float("inf")
            history: List[Dict[str, Any]] = []
            total       = len(cols)
            drops       = 0
            print(f"[MPI] Ranks: {size}  —  Fresh run with {len(cols)} features.", flush=True)
    else:
        cols = best_feats = history = best_mse = total = drops = None

    cols, best_feats, best_mse, total, drops = comm.bcast(
        (cols, best_feats, best_mse, total, drops), root=0)

    while len(cols) > min_features and drops < max_drops:
        # ---------- hyper-opt ----------
        if rank == 0 and verbose:
            print(f"\n[Iter] Optimising on {len(cols)} features…", flush=True)
            best_params = bayes_opt_nn(X_df[cols], y, max_evals=bayes_evals, random_state=seed)
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # ---------- distribute repeats ----------
        seeds = [seed + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # Fresh split + fresh model per repeat
            X_tr, X_val, y_tr, y_val = train_test_split(X_df[cols], y, test_size=0.2, random_state=s)
            scaler = StandardScaler().fit(X_tr)

            tf.keras.backend.clear_session()
            model = _build_nn6(len(cols), best_params, seed=s)
            model.fit(
                scaler.transform(X_tr), y_tr,
                epochs=best_params["epochs"],
                batch_size=best_params["batch_size"],
                verbose=0,
            )

            # MSE for this repeat
            preds = model.predict(scaler.transform(X_val), verbose=0).flatten()
            local_mses.append(mean_squared_error(y_val, preds))

            # Permutation importance (on unscaled X; wrapper handles scaling)
            Xv_use, yv_use = _downsample(X_val, y_val, pi_max_rows, s)
            pi = permutation_importance(
                ScaledModel(model, scaler), Xv_use, yv_use,
                scoring="neg_mean_squared_error",
                n_repeats=pi_repeats, random_state=s, n_jobs=1
            )
            local_imps.append(pi.importances_mean)

        gathered_mses  = comm.gather(local_mses, root=0)
        gathered_imps  = comm.gather(local_imps, root=0)
        gathered_seeds = comm.gather(my_seeds,   root=0)

        if rank == 0:
            mses  = [m for sub in gathered_mses for m in sub]
            imps  = [v for sub in gathered_imps for v in sub]
            seeds_all = [s for sub in gathered_seeds for s in sub]
            if len(mses) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # —— Log every repeat's MSE
            iter_id = len(history) + 1
            n_feat  = len(cols)
            mse_csv = OUTDIR / "repeats_mse.csv"
            need_header = not mse_csv.exists()
            with mse_csv.open("a") as f:
                if need_header:
                    f.write("iter,n_features,seed,mse\n")
                for sd, m in zip(seeds_all, mses):
                    f.write(f"{iter_id},{n_feat},{sd},{m}\n")

            # Averages for decision
            avg_mse = float(np.mean(mses))
            avg_imp = np.mean(imps, axis=0)

            history.append(dict(
                n_features=len(cols), mse=avg_mse,
                kept_cols=cols.copy(), best_params=best_params.copy())
            )

            if avg_mse < best_mse:
                best_mse = avg_mse
                best_feats = cols.copy()

            # drop worst feature
            if len(cols) > min_features:
                worst = int(np.argmin(avg_imp))
                dropped = cols.pop(worst)
                drops += 1
                cont = drops < max_drops and len(cols) > min_features
                if verbose:
                    kept = len(cols)
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({total-kept}/{total} removed) "
                          f"[{drops}/{max_drops} this pass]", flush=True)
            else:
                cont = False

            _save_ckpt(ckpt_path, dict(
                cols=cols, best_mse=best_mse,
                best_features=best_feats, history=history, total=total)
            )
            state = dict(cols=cols, best_mse=best_mse,
                         best_features=best_feats, cont=cont)
        else:
            state = None

        state = comm.bcast(state, root=0)
        cols, best_mse, best_feats = state["cols"], state["best_mse"], state["best_features"]
        if not state["cont"]:
            break

    # ---------- final I/O ----------
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_feats, name="kept_columns").to_csv(OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols, name="current_cols_after_pass").to_csv(OUTDIR / "current_cols_after_pass.csv", index=False)
        X_df[best_feats].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] Pass finished with {len(cols)} features. Best MSE so far: {best_mse:.6e}")

# ────────────────────────── entry point ─────────────────────────────
def main():
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}", flush=True)
    df = pd.read_csv(CSV_PATH)
    if TARGET_COL not in df.columns:
        raise SystemExit(f"Dataset missing column '{TARGET_COL}'")
    # Drop target + known leak columns
    X_df = df.drop(columns=[TARGET_COL, "XSlow", "XSupp", "anity", "MT"], errors="ignore")
    y    = df[TARGET_COL].values

    mpi_feature_elim_nn_perm(
        X_df, y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        seed=SEED,
        bayes_evals=BAYES_EVALS,
        pi_repeats=PI_REPEATS,
        pi_max_rows=PI_MAX_VAL_ROWS,
        max_drops=MAX_DROPS_THIS_PASS,
        ckpt_path=CHECKPOINT_PATH,
        verbose=(rank == 0),
    )

if __name__ == "__main__":
    main()
