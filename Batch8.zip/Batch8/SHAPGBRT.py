#!/usr/bin/env python3
"""
MPI SHAP feature elimination for XGBoost (GBRT) with per-repeat MSE logging.

- Removes up to MAX_DROPS_THIS_PASS features per run (checkpoint after each drop).
- Resumes automatically if CHECKPOINT_PATH exists; else starts fresh.
- Drops the feature with the smallest mean |SHAP| across repeats.
- Logs EVERY repeat's MSE to OUTDIR/repeats_mse.csv.
- Excludes known leak/aux columns from training features.

Yes: for each repeat we do a new train/val split and **retrain a fresh model**.
"""

from pathlib import Path
import json
from typing import List, Dict, Any

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import xgboost as xgb

# --------------------------- HARD-CODED SETTINGS ----------------------------
# Data
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"
LEAKY_OR_DROP_COLS  = ["XSlow", "XSupp", "anity", "MT"]  # ignored if missing

# Elimination limits
MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 100

# Randomness / repeats
SEED                = 42
REPEATS             = 5   # total random splits per subset (parallel across MPI ranks)

# Hyperopt budget
BAYES_EVALS         = 30

# SHAP budget
SHAP_MAX_ROWS       = 1024  # cap validation rows used for SHAP per repeat

# Checkpoint + outputs
CHECKPOINT_PATH     = Path("SHAP_feature_elim.ckpt.json")
OUTDIR              = Path("SHAP_feature_elim_out_pass1")

# XGBoost training threads per process
XGB_N_JOBS_PER_RANK = 1
# ---------------------------------------------------------------------------

# MPI init
try:
    from mpi4py import MPI
except ImportError:
    raise SystemExit("[ERROR] mpi4py is not installed in this environment.")
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# Import your Bayesian optimiser
from GBRTbAY import bayes_opt_xgb

# SHAP
try:
    import shap
except Exception as e:
    raise SystemExit(
        "[ERROR] Could not import SHAP. Install it in your job env, e.g.:\n"
        "  conda install -c conda-forge shap   (or)   pip install shap\n\n"
        f"Import error was: {e}"
    )


def _mean_abs_shap(
    model: xgb.XGBRegressor,
    X_val: pd.DataFrame,
    *,
    max_rows: int,
    seed: int,
) -> np.ndarray:
    """Compute mean absolute SHAP values per feature on a (subsampled) validation set."""
    n_features = X_val.shape[1]

    # Subsample validation rows for speed
    if len(X_val) > max_rows:
        rng = np.random.default_rng(seed)
        sel = rng.choice(len(X_val), size=max_rows, replace=False)
        X_use = X_val.iloc[sel]
    else:
        X_use = X_val

    try:
        explainer = shap.TreeExplainer(model)
        sv = explainer.shap_values(X_use)
    except Exception:
        sv = np.zeros((len(X_use), n_features), dtype=float)

    if isinstance(sv, list):  # rare multi-output case
        sv = sv[0]

    return np.mean(np.abs(sv), axis=0)  # (n_features,)


def _save_ckpt(path: Path, state: Dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w") as f:
        json.dump(state, f, indent=2)
    tmp.replace(path)


def _load_ckpt(path: Path) -> Dict[str, Any]:
    with path.open("r") as f:
        return json.load(f)


def mpi_feature_elimination_shap_ckpt(
    X: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features: int,
    repeats: int,
    random_state: int,
    bayes_max_evals: int,
    shap_max_rows: int,
    max_drops: int,
    checkpoint_path: Path,
    verbose_root: bool = True,
) -> Dict[str, Any]:
    """Run one pass: remove up to `max_drops` features, checkpoint after each."""

    # Ensure output dir exists (needed for per-repeat logging)
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # Rank 0 loads or initialises state
    if rank == 0:
        if checkpoint_path.exists():
            ckpt = _load_ckpt(checkpoint_path)
            cols = ckpt["cols"]
            best_features = ckpt["best_features"]
            best_mse = ckpt["best_mse"]
            history = ckpt["history"]
            total = ckpt.get("total", len(cols) + len(history))
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Resume] Loaded checkpoint with {len(cols)} remaining features.", flush=True)
        else:
            cols = list(X.columns)
            best_features = cols.copy()
            best_mse = float("inf")
            history: List[Dict[str, Any]] = []
            total = len(cols)
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Start] Fresh run with {len(cols)} features.", flush=True)
    else:
        cols = best_features = history = best_mse = total = drops_this_job = None

    # Broadcast initial state
    cols           = comm.bcast(cols, root=0)
    best_features  = comm.bcast(best_features, root=0)
    best_mse       = comm.bcast(best_mse, root=0)
    total          = comm.bcast(total, root=0)
    drops_this_job = comm.bcast(drops_this_job, root=0)

    # Main loop bounded by min_features and max_drops
    while len(cols) > min_features and drops_this_job < max_drops:
        # (1) Tune on current subset (rank 0)
        if rank == 0 and verbose_root:
            print(f"\n[Iter] Optimising on {len(cols)} features...", flush=True)
            best_params = bayes_opt_xgb(X[cols], y, max_evals=bayes_max_evals, random_state=random_state)
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # (2) Base model (each rank)
        base_model = xgb.XGBRegressor(
            objective="reg:squarederror",
            verbosity=0,
            n_jobs=XGB_N_JOBS_PER_RANK,
            random_state=random_state,
            **best_params,
        )

        # (3) Distribute repeats across ranks
        seeds = [random_state + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # Fresh split + fresh model for this repeat
            X_tr, X_val, y_tr, y_val = train_test_split(X[cols], y, test_size=0.2, random_state=s)
            model = base_model.__class__(**base_model.get_params())
            model.fit(X_tr, y_tr)
            preds = model.predict(X_val)
            local_mses.append(mean_squared_error(y_val, preds))

            imp = _mean_abs_shap(
                model,
                X_val,
                max_rows=shap_max_rows,
                seed=s,
            )
            local_imps.append(imp)

        # (4) Gather & decide (rank 0)
        gathered_mses  = comm.gather(local_mses, root=0)
        gathered_imps  = comm.gather(local_imps, root=0)
        gathered_seeds = comm.gather(my_seeds,   root=0)

        if rank == 0:
            # Flatten per-repeat results
            mses_flat  = [m for sub in gathered_mses for m in sub]
            imps_flat  = [v for sub in gathered_imps for v in sub]    # list of arrays
            seeds_flat = [s for sub in gathered_seeds for s in sub]

            if len(mses_flat) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # Append per-repeat MSEs to CSV
            iter_id = len(history) + 1
            n_feat  = len(cols)
            mse_path = OUTDIR / "repeats_mse.csv"
            header_needed = not mse_path.exists()
            with mse_path.open("a") as f:
                if header_needed:
                    f.write("iter,n_features,seed,mse\n")
                for s, m in zip(seeds_flat, mses_flat):
                    f.write(f"{iter_id},{n_feat},{s},{m}\n")

            # Averages for decision-making
            avg_mse = float(np.mean(mses_flat))
            avg_imp = np.mean(imps_flat, axis=0)  # mean |SHAP| per feature

            history.append({
                "n_features": len(cols),
                "mse": avg_mse,
                "kept_cols": cols.copy(),
                "best_params": best_params.copy(),
            })

            if avg_mse < best_mse:
                best_mse = avg_mse
                best_features = cols.copy()

            # Drop one
            if len(cols) <= min_features:
                cont = False
            else:
                worst_idx = int(np.argmin(avg_imp))
                dropped = cols[worst_idx]
                cols.pop(worst_idx)
                drops_this_job += 1
                cont = (len(cols) > min_features) and (drops_this_job < max_drops)
                if verbose_root:
                    kept = len(cols)
                    removed = total - kept
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({removed}/{total} removed -> {kept}/{total} remain)  "
                          f"[drops this pass: {drops_this_job}/{max_drops}]",
                          flush=True)

            # (5) Checkpoint after every drop / at end
            ckpt = {
                "cols": cols,
                "best_mse": best_mse,
                "best_features": best_features,
                "history": history,
                "total": total,
            }
            _save_ckpt(CHECKPOINT_PATH, ckpt)

            state = {"cols": cols, "best_mse": best_mse, "best_features": best_features, "cont": cont}
        else:
            state = None

        state = comm.bcast(state, root=0)
        cols = state["cols"]
        best_mse = state["best_mse"]
        best_features = state["best_features"]
        if not state["cont"]:
            break

    # Finalise outputs on rank 0
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_features, name="kept_columns").to_csv(OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols, name="current_cols_after_pass").to_csv(OUTDIR / "current_cols_after_pass.csv", index=False)
        # Export the best-feature subset of X for convenience
        X[list(best_features)].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] This pass ended with {len(cols)} features remaining.")
        print(f"Best MSE so far: {best_mse:.6e}")
    return {"best_features": best_features, "best_mse": best_mse, "cols_now": cols}


def main():
    # Load dataset (each rank; shared FS)
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}", flush=True)
    df = pd.read_csv(CSV_PATH)

    if TARGET_COL not in df.columns:
        raise SystemExit(f"Target column '{TARGET_COL}' not found in {CSV_PATH}.")

    # Drop target + known leak/aux columns from the feature matrix
    X_df = df.drop(columns=[TARGET_COL, *LEAKY_OR_DROP_COLS], errors="ignore")
    y = df[TARGET_COL].values

    mpi_feature_elimination_shap_ckpt(
        X_df,
        y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        random_state=SEED,
        bayes_max_evals=BAYES_EVALS,
        shap_max_rows=SHAP_MAX_ROWS,
        max_drops=MAX_DROPS_THIS_PASS,
        checkpoint_path=CHECKPOINT_PATH,
        verbose_root=(rank == 0),
    )


if __name__ == "__main__":
    main()
