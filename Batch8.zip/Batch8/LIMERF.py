#!/usr/bin/env python3
"""
MPI LIME feature elimination for Random-Forest (RF6) + Bayesian optimisation
---------------------------------------------------------------------------

* Re-optimises RandomForestRegressor parameters (bayes_opt_rf) at every
  feature subset.
* Uses LIME TabularExplainer to compute mean |weight| per feature on a
  validation fold; drops the lowest-weight feature each round.
* Logs every repeat's MSE to OUTDIR/repeats_mse.csv.
* Checkpoints after every drop so you can resume in multiple passes.

Launch (Slurm):
    srun --mpi=pmix_v3 python RF_LIME_feature_elim.py
"""

# ──────────────────────────────────────────────────────────────────────
# Standard lib
# ──────────────────────────────────────────────────────────────────────
from pathlib import Path
import json
from typing import List, Dict, Any

# ──────────────────────────────────────────────────────────────────────
# Third-party
# ──────────────────────────────────────────────────────────────────────
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import RandomForestRegressor

from mpi4py import MPI
from lime.lime_tabular import LimeTabularExplainer

# ──────────────────────────────────────────────────────────────────────
# Local imports (same folder)
# ──────────────────────────────────────────────────────────────────────
from RFbay import bayes_opt_rf          # Bayesian optimiser
# If you prefer your baseline factory:
# from RF6 import _build_rf as build_rf_default

# ──────────────────────────────────────────────────────────────────────
# Hard-coded settings (edit between passes)
# ──────────────────────────────────────────────────────────────────────
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"

MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 100

SEED                = 42
REPEATS             = 5
BAYES_EVALS         = 30

LIME_INSTANCES      = 128
LIME_SAMPLES        = 2000

CHECKPOINT_PATH     = Path("RF_LIME_feature_elim.ckpt.json")
OUTDIR              = Path("RF_LIME_feature_elim_out_pass1")

# Limit threads per MPI rank to avoid oversubscription
RF_N_JOBS_PER_RANK  = 1

# ──────────────────────────────────────────────────────────────────────
# MPI setup
# ──────────────────────────────────────────────────────────────────────
comm  = MPI.COMM_WORLD
rank  = comm.Get_rank()
size  = comm.Get_size()

# ──────────────────────────────────────────────────────────────────────
# LIME helper
# ──────────────────────────────────────────────────────────────────────
def _lime_mean_abs_importance(
    model: RandomForestRegressor,
    X_train_bg: pd.DataFrame,
    X_val: pd.DataFrame,
    *,
    feature_names: List[str],
    n_instances: int,
    num_samples: int,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n_features = X_val.shape[1]

    explainer = LimeTabularExplainer(
        training_data=X_train_bg.values,
        feature_names=feature_names,
        mode="regression",
        discretize_continuous=True,
        sample_around_instance=True,
        random_state=seed,
        verbose=False,
    )

    n_instances = min(n_instances, len(X_val))
    sel_idx = rng.choice(len(X_val), size=n_instances, replace=False)
    agg = np.zeros(n_features, dtype=float)

    def predict_fn(x):
        return model.predict(x).reshape(-1)

    for i in sel_idx:
        row = X_val.iloc[i].values
        exp = explainer.explain_instance(
            row,
            predict_fn=predict_fn,
            num_features=n_features,
            num_samples=num_samples,
        )
        # In LIME regression, local_exp is keyed by 1
        for j, w in exp.local_exp[1]:
            agg[j] += abs(w)

    return agg / max(1, n_instances)

# ──────────────────────────────────────────────────────────────────────
# Checkpoint utils
# ──────────────────────────────────────────────────────────────────────
def _save_ckpt(path: Path, state: Dict[str, Any]):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(state, indent=2))
    tmp.replace(path)

def _load_ckpt(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text())

# ──────────────────────────────────────────────────────────────────────
# Main elimination routine
# ──────────────────────────────────────────────────────────────────────
def mpi_feature_elim_rf_lime(
    X_df: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features: int,
    repeats: int,
    seed: int,
    bayes_evals: int,
    lime_instances: int,
    lime_samples: int,
    max_drops: int,
    checkpoint: Path,
    verbose: bool = True,
):
    # Ensure OUTDIR exists for per-repeat logging
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # -------- init / resume (rank 0) --------
    if rank == 0:
        if checkpoint.exists():
            ckpt = _load_ckpt(checkpoint)
            cols, best_feats = ckpt["cols"], ckpt["best_features"]
            best_mse, history, total = ckpt["best_mse"], ckpt["history"], ckpt["total"]
            drops_this = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Resume] {len(cols)} features remain.")
        else:
            cols = list(X_df.columns)
            best_feats = cols.copy()
            best_mse = float("inf")
            history: List[Dict[str, Any]] = []
            total = len(cols)
            drops_this = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Start] Fresh run with {len(cols)} features.")
    else:
        cols = best_feats = history = best_mse = total = drops_this = None

    # Broadcast state
    cols, best_feats, best_mse, total, drops_this = comm.bcast(
        (cols, best_feats, best_mse, total, drops_this), root=0
    )

    while len(cols) > min_features and drops_this < max_drops:
        # -------- hyper-opt (rank 0) --------
        if rank == 0 and verbose:
            print(f"\n[Iter] Optimising on {len(cols)} features…", flush=True)
            best_params = bayes_opt_rf(
                X_df[cols], y, max_evals=bayes_evals, random_state=seed
            )
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # -------- distribute repeats --------
        seeds = [seed + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # Fresh split + fresh RF per repeat (retrained)
            X_tr, X_val, y_tr, y_val = train_test_split(
                X_df[cols], y, test_size=0.2, random_state=s
            )
            model = RandomForestRegressor(
                random_state=s, n_jobs=RF_N_JOBS_PER_RANK, **best_params
            ).fit(X_tr, y_tr)

            preds = model.predict(X_val)
            local_mses.append(mean_squared_error(y_val, preds))

            imp = _lime_mean_abs_importance(
                model, X_tr, X_val,
                feature_names=cols,
                n_instances=lime_instances,
                num_samples=lime_samples,
                seed=s,
            )
            local_imps.append(imp)

        gathered_mses  = comm.gather(local_mses,  root=0)
        gathered_imps  = comm.gather(local_imps,  root=0)
        gathered_seeds = comm.gather(my_seeds,    root=0)

        if rank == 0:
            mses      = [m  for sub in gathered_mses  for m  in sub]
            imps      = [v  for sub in gathered_imps  for v  in sub]
            seeds_all = [sd for sub in gathered_seeds for sd in sub]
            if len(mses) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # ---- log per-repeat MSEs
            iter_id  = len(history) + 1
            n_feat   = len(cols)
            mse_csv  = OUTDIR / "repeats_mse.csv"
            need_hdr = not mse_csv.exists()
            with mse_csv.open("a") as f:
                if need_hdr:
                    f.write("iter,n_features,seed,mse\n")
                for sd, m in zip(seeds_all, mses):
                    f.write(f"{iter_id},{n_feat},{sd},{m}\n")

            # Averages for decision
            avg_mse = float(np.mean(mses))
            avg_imp = np.mean(imps, axis=0)

            history.append(
                dict(n_features=len(cols), mse=avg_mse,
                     kept_cols=cols.copy(), best_params=best_params.copy())
            )

            if avg_mse < best_mse:
                best_mse = avg_mse
                best_feats = cols.copy()

            # drop worst
            if len(cols) > min_features:
                worst_idx = int(np.argmin(avg_imp))
                dropped = cols.pop(worst_idx)
                drops_this += 1
                cont = drops_this < max_drops and len(cols) > min_features
                if verbose:
                    kept = len(cols)
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({total-kept}/{total} removed)  "
                          f"[{drops_this}/{max_drops} this pass]")
            else:
                cont = False

            _save_ckpt(
                checkpoint,
                dict(cols=cols, best_mse=best_mse,
                     best_features=best_feats, history=history, total=total)
            )
            state = dict(cols=cols, best_mse=best_mse,
                         best_features=best_feats, cont=cont)
        else:
            state = None

        state = comm.bcast(state, root=0)
        cols, best_mse, best_feats = state["cols"], state["best_mse"], state["best_features"]
        if not state["cont"]:
            break

    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_feats, name="kept_columns").to_csv(
            OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols, name="current_cols_after_pass").to_csv(
            OUTDIR / "current_cols_after_pass.csv", index=False)
        X_df[best_feats].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] Pass finished with {len(cols)} features. "
              f"Best MSE so far: {best_mse:.6e}")

# ──────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────
def main():
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}")
    df = pd.read_csv(CSV_PATH)
    if TARGET_COL not in df.columns:
        raise SystemExit(f"Dataset missing column '{TARGET_COL}'")
    # Drop target + leak columns
    X_df = df.drop(columns=[TARGET_COL, "XSlow", "XSupp", "anity", "MT"], errors="ignore")
    y    = df[TARGET_COL].values

    mpi_feature_elim_rf_lime(
        X_df, y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        seed=SEED,
        bayes_evals=BAYES_EVALS,
        lime_instances=LIME_INSTANCES,
        lime_samples=LIME_SAMPLES,
        max_drops=MAX_DROPS_THIS_PASS,
        checkpoint=CHECKPOINT_PATH,
        verbose=(rank == 0),
    )

if __name__ == "__main__":
    main()
