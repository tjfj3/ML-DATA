#!/usr/bin/env python3
"""
MPI Permutation-Importance feature elimination for XGBoost (GBRT)
with per-repeat MSE logging and Hyperopt re-optimisation.

- Removes up to MAX_DROPS_THIS_PASS features per run (checkpoint each drop).
- Resumes if CHECKPOINT_PATH exists; else starts fresh.
- Drops the feature with the smallest average permutation importance across repeats.
- Writes EVERY repeat's MSE to OUTDIR/repeats_mse.csv.
"""

from pathlib import Path
import json
from typing import List, Dict, Any, Tuple

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.inspection import permutation_importance
import xgboost as xgb

# ───────────────────────────────────────────────────────────────────────
# Settings
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"
LEAKY_OR_DROP_COLS  = ["XSlow", "XSupp", "anity", "MT"]  # silently ignored if missing

MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 100

SEED                = 42
REPEATS             = 5

BAYES_EVALS         = 30

PI_REPEATS          = 5
PI_MAX_VAL_ROWS     = 2000

CHECKPOINT_PATH     = Path("pi_feature_elim.ckpt.json")
OUTDIR              = Path("pi_feature_elim_out_pass1")

XGB_N_JOBS_PER_RANK = 1
# ───────────────────────────────────────────────────────────────────────

# MPI init
try:
    from mpi4py import MPI
except ImportError:
    raise SystemExit("[ERROR] mpi4py is not installed in this environment.")
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# Bayesian optimiser
from GBRTbAY import bayes_opt_xgb


def _downsample_val(
    X_val: pd.DataFrame, y_val: np.ndarray, max_rows: int, seed: int
) -> Tuple[pd.DataFrame, np.ndarray]:
    """Uniformly downsample the validation set to at most max_rows for PI speed."""
    if len(X_val) <= max_rows:
        return X_val, y_val
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(X_val), size=max_rows, replace=False)
    return X_val.iloc[idx], y_val[idx]


def _permutation_importance_mean(
    model: xgb.XGBRegressor,
    X_val: pd.DataFrame,
    y_val: np.ndarray,
    *,
    n_repeats: int,
    seed: int,
) -> np.ndarray:
    """
    Mean permutation importance per feature on the provided validation set.
    scoring='neg_mean_squared_error' -> higher importance means larger MSE drop when permuting.
    """
    result = permutation_importance(
        model,
        X_val,
        y_val,
        scoring="neg_mean_squared_error",
        n_repeats=n_repeats,
        random_state=seed,
        n_jobs=1,  # 1 per rank to avoid oversubscription
    )
    return result.importances_mean  # shape (n_features,)


def _save_ckpt(path: Path, state: Dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w") as f:
        json.dump(state, f, indent=2)
    tmp.replace(path)


def _load_ckpt(path: Path) -> Dict[str, Any]:
    with path.open("r") as f:
        return json.load(f)


def mpi_feature_elimination_pi_ckpt(
    X: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features: int,
    repeats: int,
    random_state: int,
    bayes_max_evals: int,
    pi_repeats: int,
    pi_max_val_rows: int,
    max_drops: int,
    checkpoint_path: Path,
    verbose_root: bool = True,
) -> Dict[str, Any]:
    """Run one pass: remove up to `max_drops` features, checkpoint after each."""

    # Make sure OUTDIR exists (for per-repeat logging)
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # Rank 0 loads or initializes state
    if rank == 0:
        if checkpoint_path.exists():
            ckpt = _load_ckpt(checkpoint_path)
            cols = ckpt["cols"]
            best_features = ckpt["best_features"]
            best_mse = ckpt["best_mse"]
            history = ckpt["history"]
            total = ckpt.get("total", len(cols) + len(history))
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Resume] Loaded checkpoint with {len(cols)} remaining features.", flush=True)
        else:
            cols = list(X.columns)
            best_features = cols.copy()
            best_mse = float("inf")
            history: List[Dict[str, Any]] = []
            total = len(cols)
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Start] Fresh run with {len(cols)} features.", flush=True)
    else:
        cols = best_features = history = best_mse = total = drops_this_job = None

    # Broadcast initial state
    cols           = comm.bcast(cols, root=0)
    best_features  = comm.bcast(best_features, root=0)
    best_mse       = comm.bcast(best_mse, root=0)
    total          = comm.bcast(total, root=0)
    drops_this_job = comm.bcast(drops_this_job, root=0)

    # Main loop
    while len(cols) > min_features and drops_this_job < max_drops:
        # (1) Hyperopt tuning on rank 0
        if rank == 0 and verbose_root:
            print(f"\n[Iter] Optimising on {len(cols)} features...", flush=True)
            best_params = bayes_opt_xgb(X[cols], y, max_evals=bayes_max_evals, random_state=random_state)
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # (2) Base model (each rank)
        base_model = xgb.XGBRegressor(
            objective="reg:squarederror",
            verbosity=0,
            n_jobs=XGB_N_JOBS_PER_RANK,
            random_state=random_state,
            **best_params,
        )

        # (3) Distribute repeats across ranks
        seeds = [random_state + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # Fresh split + fresh model for this repeat
            X_tr, X_val, y_tr, y_val = train_test_split(X[cols], y, test_size=0.2, random_state=s)
            model = base_model.__class__(**base_model.get_params())
            model.fit(X_tr, y_tr)

            # Evaluate
            preds = model.predict(X_val)
            local_mses.append(mean_squared_error(y_val, preds))

            # Downsample val for PI + compute PI
            Xv_use, yv_use = _downsample_val(X_val, y_val, pi_max_val_rows, seed=s)
            imp = _permutation_importance_mean(
                model,
                Xv_use,
                yv_use,
                n_repeats=pi_repeats,
                seed=s,
            )
            local_imps.append(imp)

        # (4) Gather & decide (rank 0)
        gathered_mses  = comm.gather(local_mses, root=0)
        gathered_imps  = comm.gather(local_imps, root=0)
        gathered_seeds = comm.gather(my_seeds,   root=0)

        if rank == 0:
            # Flatten per-repeat results
            mses_flat  = [m for sub in gathered_mses for m in sub]
            imps_flat  = [v for sub in gathered_imps for v in sub]
            seeds_flat = [s for sub in gathered_seeds for s in sub]

            if len(mses_flat) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # Per-repeat MSE logging
            iter_id = len(history) + 1
            n_feat  = len(cols)
            mse_path = OUTDIR / "repeats_mse.csv"
            header_needed = not mse_path.exists()
            with mse_path.open("a") as f:
                if header_needed:
                    f.write("iter,n_features,seed,mse\n")
                for s, m in zip(seeds_flat, mses_flat):
                    f.write(f"{iter_id},{n_feat},{s},{m}\n")

            # Averages used for elimination decision
            avg_mse = float(np.mean(mses_flat))
            avg_imp = np.mean(imps_flat, axis=0)  # mean importance per feature

            history.append({
                "n_features": len(cols),
                "mse": avg_mse,
                "kept_cols": cols.copy(),
                "best_params": best_params.copy(),
            })

            if avg_mse < best_mse:
                best_mse = avg_mse
                best_features = cols.copy()

            # Drop least important feature
            if len(cols) <= min_features:
                cont = False
            else:
                worst_idx = int(np.argmin(avg_imp))
                dropped = cols[worst_idx]
                cols.pop(worst_idx)
                drops_this_job += 1
                cont = (len(cols) > min_features) and (drops_this_job < max_drops)
                if verbose_root:
                    kept = len(cols)
                    removed = total - kept
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({removed}/{total} removed → {kept}/{total} remain)  "
                          f"[drops this pass: {drops_this_job}/{max_drops}]",
                          flush=True)

            # (5) Checkpoint after every drop / at end
            ckpt = {
                "cols": cols,
                "best_mse": best_mse,
                "best_features": best_features,
                "history": history,
                "total": total,
            }
            _save_ckpt(CHECKPOINT_PATH, ckpt)

            state = {"cols": cols, "best_mse": best_mse, "best_features": best_features, "cont": cont}
        else:
            state = None

        state = comm.bcast(state, root=0)
        cols = state["cols"]
        best_mse = state["best_mse"]
        best_features = state["best_features"]
        if not state["cont"]:
            break

    # Finalise outputs on rank 0
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_features, name="kept_columns").to_csv(OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols, name="current_cols_after_pass").to_csv(OUTDIR / "current_cols_after_pass.csv", index=False)
        X[list(best_features)].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] This pass ended with {len(cols)} features remaining.")
        print(f"Best MSE so far: {best_mse:.6e}")
    return {"best_features": best_features, "best_mse": best_mse, "cols_now": cols}


def main():
    # Load dataset (each rank; shared FS)
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}", flush=True)
    df = pd.read_csv(CSV_PATH)
    if TARGET_COL not in df.columns:
        raise SystemExit(f"Target column '{TARGET_COL}' not found in {CSV_PATH}.")

    # Drop target + known leaks/aux columns from features
    X_df = df.drop(columns=[TARGET_COL, *LEAKY_OR_DROP_COLS], errors="ignore")
    y = df[TARGET_COL].values

    mpi_feature_elimination_pi_ckpt(
        X_df,
        y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        random_state=SEED,
        bayes_max_evals=BAYES_EVALS,
        pi_repeats=PI_REPEATS,
        pi_max_val_rows=PI_MAX_VAL_ROWS,
        max_drops=MAX_DROPS_THIS_PASS,
        checkpoint_path=CHECKPOINT_PATH,
        verbose_root=(rank == 0),
    )


if __name__ == "__main__":
    main()
