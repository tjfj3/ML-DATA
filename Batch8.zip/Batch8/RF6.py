import sys
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

# ------------------------------------------------------------------ #
# tuned (but lightweight) RF hyper-parameters                        #
# ------------------------------------------------------------------ #
PARAMS = dict(
    n_estimators=1200,       # more trees → smoother, less variance
    max_depth=50,        # let trees grow; control with min_samples_leaf
    min_samples_leaf=1,    # small smoothing; raise if over-fitting
    max_features=None,   # good default for RF on tabular data
    random_state=42,
    n_jobs=-1,             # use all CPU cores
    oob_score=False,
)

# ------------------------------------------------------------------ #
# helper                                                             #
# ------------------------------------------------------------------ #
def _build_rf() -> RandomForestRegressor:
    return RandomForestRegressor(**PARAMS)

def predict_rf(train_csv: str, target_csv: str) -> pd.DataFrame:
    """Return ENG, actual, rf_pred, rf_err as a DataFrame."""

    train = pd.read_csv(train_csv)
    test  = pd.read_csv(target_csv)

    X_train, y_train = train.drop(columns=["XS"]), train["XS"].values
    X_test,  y_test  = test .drop(columns=["XS", "XSlow", "XSupp"], errors="ignore"), test["XS"].values

    model = _build_rf().fit(X_train, y_train)
    y_pred = model.predict(X_test)

    out = pd.DataFrame({
        "ENG":    X_test.get("ERG", np.arange(len(X_test))).astype(float),
        "actual": y_test,
        "rf_pred": y_pred,
    })
    out["rf_err"] = out["rf_pred"] - out["actual"]
    return out

# ------------------------------------------------------------------ #
# CLI                                                                #
# ------------------------------------------------------------------ #
if __name__ == "__main__":
    tr_csv, tgt_csv, out_csv = (
        sys.argv[1:4] if len(sys.argv) >= 4 else
        ("..\\Batch5\\train4.csv", "..\\Batch5\\target4.csv", "predictions_rf.csv")
    )

    df = predict_rf(tr_csv, tgt_csv)
    df.to_csv(out_csv, index=False)

    mse = mean_squared_error(df.actual, df.rf_pred)
    print(f"RF predictions written to {out_csv}  (MSE={mse:.4e})")