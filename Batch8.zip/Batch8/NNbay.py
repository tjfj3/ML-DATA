"""
NN6bayes.py
-----------

Hyperopt Bayesian optimisation for the NN6 model.

Usage example
-------------
from NN6bayes import bayes_opt_nn
best_params = bayes_opt_nn(X_train, y_train, max_evals=30, random_state=42)
"""

import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="tensorflow")

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
import tensorflow as tf
from tensorflow import keras

# ───────────────────────────────────────────────────────────────────────
# Hyper‑parameter search space
# Adjust bounds as you wish
# ───────────────────────────────────────────────────────────────────────
SPACE = {
    "n_layers":   hp.quniform("n_layers", 1, 5, 1),         # 1‑5 hidden layers
    "units":      hp.quniform("units", 64, 512, 32),        # 64,96,…512
    "activation": hp.choice("activation", ["relu", "gelu", "tanh"]),
    "dropout":    hp.uniform("dropout", 0.0, 0.5),          # 0‑0.5
    "learning_rate": hp.loguniform("learning_rate", np.log(1e-4), np.log(1e-2)),
    "l2":         hp.loguniform("l2", np.log(1e-6), np.log(1e-2)),
    "batch_size": hp.choice("batch_size", [32, 64, 128, 256]),
    "epochs":     hp.quniform("epochs", 20, 80, 5),         # 20,25,…80
}

# ───────────────────────────────────────────────────────────────────────
# Model factory
# ───────────────────────────────────────────────────────────────────────
def _build_model(input_dim: int, params: dict, seed: int) -> keras.Model:
    tf.random.set_seed(seed)
    reg = keras.regularizers.l2(params["l2"])
    layers = [keras.layers.Input(shape=(input_dim,))]
    for _ in range(int(params["n_layers"])):
        layers.append(
            keras.layers.Dense(
                int(params["units"]),
                activation=params["activation"],
                kernel_regularizer=reg,
            )
        )
        if params["dropout"] > 0:
            layers.append(keras.layers.Dropout(params["dropout"]))
    layers.append(keras.layers.Dense(1))
    model = keras.Sequential(layers)
    model.compile(
        optimizer=keras.optimizers.Adam(params["learning_rate"]),
        loss="mse",
    )
    return model


# ───────────────────────────────────────────────────────────────────────
# Main optimisation function
# ───────────────────────────────────────────────────────────────────────
def bayes_opt_nn(X: pd.DataFrame, y: np.ndarray,
                 *, max_evals: int = 30, random_state: int = 42) -> dict:
    """
    Bayesian optimisation for NN6.

    Parameters
    ----------
    X, y          : training data (DataFrame + 1‑D array)
    max_evals     : Hyperopt trials
    random_state  : base RNG seed (reproducible)

    Returns
    -------
    best_params   : dict with the same keys as SPACE, all python types (int/float/str)
    """
    # Fixed train/validation split for reproducibility
    X_tr, X_val, y_tr, y_val = train_test_split(
        X, y, test_size=0.2, random_state=random_state
    )
    scaler = StandardScaler().fit(X_tr)
    X_tr_s = scaler.transform(X_tr)
    X_val_s = scaler.transform(X_val)

    def objective(hparams):
        # Cast Hyperopt floats -> int where needed
        hparams = hparams.copy()
        hparams["n_layers"] = int(hparams["n_layers"])
        hparams["units"] = int(hparams["units"])
        hparams["batch_size"] = int(hparams["batch_size"])
        hparams["epochs"] = int(hparams["epochs"])

        tf.keras.backend.clear_session()
        model = _build_model(X.shape[1], hparams, seed=random_state)

        model.fit(
            X_tr_s,
            y_tr,
            epochs=hparams["epochs"],
            batch_size=hparams["batch_size"],
            verbose=0,
        )

        preds = model.predict(X_val_s, verbose=0).flatten()
        mse = np.mean((preds - y_val) ** 2)

        return {"loss": mse, "status": STATUS_OK}

    trials = Trials()
    best = fmin(
        fn=objective,
        space=SPACE,
        algo=tpe.suggest,
        max_evals=max_evals,
        trials=trials,
        rstate=np.random.default_rng(random_state),
    )

    # Hyperopt returns indices for hp.choice; map back to actual values
    best["activation"] = ["relu", "gelu", "tanh"][best["activation"]]
    best["batch_size"] = [32, 64, 128, 256][best["batch_size"]]

    # Cast floats to int where appropriate
    best = {
        "n_layers": int(best["n_layers"]),
        "units": int(best["units"]),
        "activation": best["activation"],
        "dropout": float(best["dropout"]),
        "learning_rate": float(best["learning_rate"]),
        "l2": float(best["l2"]),
        "batch_size": int(best["batch_size"]),
        "epochs": int(best["epochs"]),
    }
    return best


# ───────────────────────────────────────────────────────────────────────
# Quick CLI test (optional)
# ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse, time, sys
    p = argparse.ArgumentParser()
    p.add_argument("csv", help="CSV with features + XS column")
    p.add_argument("--max-evals", type=int, default=30)
    args = p.parse_args()

    df = pd.read_csv(args.csv)
    if "XS" not in df.columns:
        sys.exit("CSV must contain 'XS' column.")
    X, y = df.drop(columns=["XS"]), df["XS"].values

    t0 = time.time()
    best = bayes_opt_nn(X, y, max_evals=args.max_evals)
    dur = time.time() - t0

    print("Best hyper‑parameters:")
    for k, v in best.items():
        print(f"  {k}: {v}")
    print(f"\nOptimisation took {dur/60:.1f} min")
