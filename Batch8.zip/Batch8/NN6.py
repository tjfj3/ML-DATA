import sys
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from sklearn.preprocessing import StandardScaler

PARAMS = dict(
    n_layers=3,
    units=416,
    activation="relu",
    dropout=0.04828500783240436,
    learning_rate=9.055611277757749e-4,
    l2=0.008372802913672647,
    batch_size=64,
    epochs=40,
)


def _build_model(input_dim: int) -> keras.Model:
    reg = keras.regularizers.l2(PARAMS["l2"])
    layers = [keras.layers.Input(shape=(input_dim,))]
    for _ in range(PARAMS["n_layers"]):
        layers.append(keras.layers.Dense(PARAMS["units"], activation=PARAMS["activation"], kernel_regularizer=reg))
        if PARAMS["dropout"] > 0:
            layers.append(keras.layers.Dropout(PARAMS["dropout"]))
    layers.append(keras.layers.Dense(1))
    model = keras.Sequential(layers)
    model.compile(optimizer=keras.optimizers.Adam(PARAMS["learning_rate"]), loss="mse")
    return model


def predict_nn(train_csv: str, target_csv: str) -> pd.DataFrame:
    """Return ENG, actual, nn_pred, nn_err as a DataFrame."""

    train = pd.read_csv(train_csv)
    test  = pd.read_csv(target_csv)

    X_train, y_train = train.drop(columns=["XS"]), train["XS"].values
    X_test,  y_test  = test.drop(columns=["XS", "XSlow", "XSupp"], errors="ignore"), test["XS"].values

    scaler = StandardScaler().fit(X_train)
    model  = _build_model(X_train.shape[1])
    model.fit(scaler.transform(X_train), y_train, epochs=PARAMS["epochs"], batch_size=PARAMS["batch_size"], verbose=0)

    y_pred = model.predict(scaler.transform(X_test), verbose=0).flatten()
    out = pd.DataFrame({
        "ENG": X_test.get("ERG", np.arange(len(X_test))).astype(float),
        "actual": y_test,
        "nn_pred": y_pred,
    })
    out["nn_err"] = out["nn_pred"] - out["actual"]
    return out


if __name__ == "__main__":
    tr, tgt, out_csv = sys.argv[1:4] if len(sys.argv) >= 4 else (
        "..\\Batch5\\train4.csv", "..\\Batch5\\target4.csv", "predictions_nn.csv")
    df_out = predict_nn(tr, tgt)
    df_out.to_csv(out_csv, index=False)
    print(f"NN predictions written to {out_csv}  (MSE={np.mean(df_out.nn_err**2):.4e})")
