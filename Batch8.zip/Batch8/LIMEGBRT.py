#!/usr/bin/env python3
"""
MPI LIME feature elimination for XGBoost (GBRT) with per-repeat MSE logging.
- Removes up to MAX_DROPS_THIS_PASS features per run (checkpoint each drop).
- Resumes if CHECKPOINT_PATH exists; else starts fresh.
- Drops the feature with the smallest mean |LIME weight| across repeats.
- Writes EVERY repeat's MSE to OUTDIR/repeats_mse.csv.
"""

from pathlib import Path
import json
from typing import List, Dict, Any

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import xgboost as xgb
from lime.lime_tabular import LimeTabularExplainer

# ───────────────────────────────────────────────────────────────────────
# Settings
CSV_PATH            = Path("../Batch5/AllClean4.csv")
TARGET_COL          = "XS"

MIN_FEATURES        = 3
MAX_DROPS_THIS_PASS = 100

SEED                = 42
REPEATS             = 5

BAYES_EVALS         = 30

LIME_INSTANCES      = 128     # validation rows explained per repeat
LIME_SAMPLES        = 2000    # perturbed samples per explanation

CHECKPOINT_PATH     = Path("LIME_feature_elim.ckpt.json")
OUTDIR              = Path("LIME_feature_elim_out_pass1")

XGB_N_JOBS_PER_RANK = 1       # avoid oversubscription under MPI
# ───────────────────────────────────────────────────────────────────────

# MPI init
try:
    from mpi4py import MPI
except ImportError:
    raise SystemExit("[ERROR] mpi4py is not installed in this environment.")
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# Bayesian optimiser
from GBRTbAY import bayes_opt_xgb


def _lime_mean_abs_importance(
    model: xgb.XGBRegressor,
    X_train_bg: pd.DataFrame,
    X_val: pd.DataFrame,
    *,
    feature_names: List[str],
    n_instances: int,
    num_samples: int,
    seed: int,
) -> np.ndarray:
    """Compute mean |LIME weight| per feature on a subsample of validation rows."""
    rng = np.random.default_rng(seed)
    n_features = X_val.shape[1]

    explainer = LimeTabularExplainer(
        training_data=X_train_bg.values,
        feature_names=list(feature_names),
        mode="regression",
        discretize_continuous=True,
        sample_around_instance=True,
        random_state=seed,
        verbose=False,
    )

    n_instances = min(n_instances, len(X_val))
    sel_idx = rng.choice(len(X_val), size=n_instances, replace=False)
    agg = np.zeros(n_features, dtype=float)

    def predict_fn(x: np.ndarray) -> np.ndarray:
        # LIME calls with np.array, ensure 1D return
        return model.predict(x).reshape(-1)

    for i in sel_idx:
        row = X_val.iloc[i].values
        exp = explainer.explain_instance(
            data_row=row,
            predict_fn=predict_fn,
            num_features=n_features,   # request weights for all features
            num_samples=num_samples,
        )
        # local_exp is a dict: {0: [(feature_index, weight), ...]}
        local_map = next(iter(exp.local_exp.values()))
        for j, w in local_map:
            agg[j] += abs(w)

    return agg / max(1, n_instances)


def _save_ckpt(path: Path, state: Dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w") as f:
        json.dump(state, f, indent=2)
    tmp.replace(path)


def _load_ckpt(path: Path) -> Dict[str, Any]:
    with path.open("r") as f:
        return json.load(f)


def mpi_feature_elimination_lime_ckpt(
    X: pd.DataFrame,
    y: np.ndarray,
    *,
    min_features: int,
    repeats: int,
    random_state: int,
    bayes_max_evals: int,
    lime_instances: int,
    lime_samples: int,
    max_drops: int,
    checkpoint_path: Path,
    verbose_root: bool = True,
) -> Dict[str, Any]:
    """Run one pass: remove up to `max_drops` features, checkpoint after each."""

    # Ensure OUTDIR exists (for per-repeat logging)
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)

    # Rank 0: load or init state
    if rank == 0:
        if checkpoint_path.exists():
            ckpt = _load_ckpt(checkpoint_path)
            cols = ckpt["cols"]
            best_features = ckpt["best_features"]
            best_mse = ckpt["best_mse"]
            history = ckpt["history"]
            total = ckpt.get("total", len(cols) + len(history))
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Resume] Loaded checkpoint with {len(cols)} remaining features.", flush=True)
        else:
            cols = list(X.columns)
            best_features = cols.copy()
            best_mse = float("inf")
            history: List[Dict[str, Any]] = []
            total = len(cols)
            drops_this_job = 0
            print(f"[MPI] Ranks: {size}")
            print(f"[Start] Fresh run with {len(cols)} features.", flush=True)
    else:
        cols = best_features = history = best_mse = total = drops_this_job = None

    # Broadcast initial state
    cols           = comm.bcast(cols, root=0)
    best_features  = comm.bcast(best_features, root=0)
    best_mse       = comm.bcast(best_mse, root=0)
    total          = comm.bcast(total, root=0)
    drops_this_job = comm.bcast(drops_this_job, root=0)

    # Main loop
    while len(cols) > min_features and drops_this_job < max_drops:
        # (1) Hyperopt tuning on rank 0
        if rank == 0 and verbose_root:
            print(f"\n[Iter] Optimising on {len(cols)} features...", flush=True)
            best_params = bayes_opt_xgb(X[cols], y, max_evals=bayes_max_evals, random_state=random_state)
        else:
            best_params = None
        best_params = comm.bcast(best_params, root=0)

        # (2) Base model (each rank)
        base_model = xgb.XGBRegressor(
            objective="reg:squarederror",
            verbosity=0,
            n_jobs=XGB_N_JOBS_PER_RANK,
            random_state=random_state,
            **best_params,
        )

        # (3) Distribute repeats across ranks
        seeds = [random_state + i for i in range(repeats)]
        my_seeds = seeds[rank::size]

        local_mses, local_imps = [], []
        for s in my_seeds:
            # Fresh split + fresh model for this repeat
            X_tr, X_val, y_tr, y_val = train_test_split(X[cols], y, test_size=0.2, random_state=s)
            model = base_model.__class__(**base_model.get_params())
            model.fit(X_tr, y_tr)

            # Evaluate
            preds = model.predict(X_val)
            local_mses.append(mean_squared_error(y_val, preds))

            # LIME importance on this repeat
            imp = _lime_mean_abs_importance(
                model, X_tr, X_val,
                feature_names=cols,
                n_instances=LIME_INSTANCES,
                num_samples=LIME_SAMPLES,
                seed=s,
            )
            local_imps.append(imp)

        # (4) Gather & decide (rank 0)
        gathered_mses  = comm.gather(local_mses, root=0)
        gathered_imps  = comm.gather(local_imps, root=0)
        gathered_seeds = comm.gather(my_seeds,   root=0)

        if rank == 0:
            # Flatten repeats
            mses_flat  = [m for sub in gathered_mses for m in sub]
            imps_flat  = [v for sub in gathered_imps for v in sub]
            seeds_flat = [s for sub in gathered_seeds for s in sub]

            if len(mses_flat) == 0:
                raise RuntimeError("No repeats executed; increase REPEATS or reduce MPI ranks.")

            # Per-repeat MSE logging
            iter_id = len(history) + 1
            n_feat  = len(cols)
            mse_path = OUTDIR / "repeats_mse.csv"
            header_needed = not mse_path.exists()
            with mse_path.open("a") as f:
                if header_needed:
                    f.write("iter,n_features,seed,mse\n")
                for s, m in zip(seeds_flat, mses_flat):
                    f.write(f"{iter_id},{n_feat},{s},{m}\n")

            # Averages for elimination decision
            avg_mse = float(np.mean(mses_flat))
            avg_imp = np.mean(imps_flat, axis=0)

            history.append({
                "n_features": len(cols),
                "mse": avg_mse,
                "kept_cols": cols.copy(),
                "best_params": best_params.copy(),
            })

            if avg_mse < best_mse:
                best_mse = avg_mse
                best_features = cols.copy()

            # Drop one
            if len(cols) <= min_features:
                cont = False
            else:
                worst_idx = int(np.argmin(avg_imp))
                dropped = cols[worst_idx]
                cols.pop(worst_idx)
                drops_this_job += 1
                cont = (len(cols) > min_features) and (drops_this_job < max_drops)
                if verbose_root:
                    kept = len(cols)
                    removed = total - kept
                    print(f"[Elim] Dropped '{dropped}' "
                          f"({removed}/{total} removed → {kept}/{total} remain)  "
                          f"[drops this pass: {drops_this_job}/{max_drops}]",
                          flush=True)

            # (5) Checkpoint
            ckpt = {
                "cols": cols,
                "best_mse": best_mse,
                "best_features": best_features,
                "history": history,
                "total": total,
            }
            _save_ckpt(CHECKPOINT_PATH, ckpt)

            state = {"cols": cols, "best_mse": best_mse, "best_features": best_features, "cont": cont}
        else:
            state = None

        state = comm.bcast(state, root=0)
        cols = state["cols"]
        best_mse = state["best_mse"]
        best_features = state["best_features"]
        if not state["cont"]:
            break

    # Finalise outputs on rank 0
    if rank == 0:
        OUTDIR.mkdir(exist_ok=True)
        pd.DataFrame(history).to_csv(OUTDIR / "feature_elim_history.csv", index=False)
        pd.Series(best_features, name="kept_columns").to_csv(OUTDIR / "kept_columns.csv", index=False)
        pd.Series(cols, name="current_cols_after_pass").to_csv(OUTDIR / "current_cols_after_pass.csv", index=False)
        X[list(best_features)].to_csv(OUTDIR / "X_best_features.csv", index=False)
        print(f"\n[Done] This pass ended with {len(cols)} features remaining.")
        print(f"Best MSE so far: {best_mse:.6e}")
    return {"best_features": best_features, "best_mse": best_mse, "cols_now": cols}


def main():
    # Load dataset (each rank; shared FS)
    if rank == 0:
        print(f"[MPI] Ranks: {size}")
        print(f"[MPI] Loading dataset: {CSV_PATH.resolve()}", flush=True)
    df = pd.read_csv(CSV_PATH)
    if TARGET_COL not in df.columns:
        raise SystemExit(f"Target column '{TARGET_COL}' not found in {CSV_PATH}.")

    # Drop target + known leak/aux columns directly here
    X_df = df.drop(columns=[TARGET_COL, "XSlow", "XSupp", "anity", "MT"], errors="ignore")
    y = df[TARGET_COL].values

    mpi_feature_elimination_lime_ckpt(
        X_df,
        y,
        min_features=MIN_FEATURES,
        repeats=REPEATS,
        random_state=SEED,
        bayes_max_evals=BAYES_EVALS,
        lime_instances=LIME_INSTANCES,
        lime_samples=LIME_SAMPLES,
        max_drops=MAX_DROPS_THIS_PASS,
        checkpoint_path=CHECKPOINT_PATH,
        verbose_root=(rank == 0),
    )


if __name__ == "__main__":
    main()
