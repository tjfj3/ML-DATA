
#Bayesian hyperparameter optimization for XGBoost regressor from loaded training data
#Uses hyperopt to find minimal Mean Squared Error (MSE) - 3-fold cross-validation.

import numpy as np
import pandas as pd
import xgboost as xgb

from sklearn.model_selection import cross_val_score, KFold
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
from sklearn.metrics import mean_squared_error

#Load all cleaned data and train

def load_training_data():
    train_df = pd.read_csv(r"../Batch5/AllClean4.csv.csv")
    X = train_df.drop(columns=["XS"])
    y = train_df["XS"].values
    return X, y

#set max number of trials and define a random state for reproduceability
def bayes_opt_xgb(X, y, max_evals=30, random_state=42):

    # Define the hyperparameter search space.
    space = {
        'n_estimators':  hp.quniform('n_estimators', 100, 1000, 50),
        'max_depth':     hp.quniform('max_depth', 2, 12, 1),
        'learning_rate': hp.loguniform('learning_rate', np.log(1e-3), np.log(0.3)),
        'subsample':     hp.uniform('subsample', 0.5, 1.0),
        'colsample_bytree': hp.uniform('colsample_bytree', 0.5, 1.0),
        'reg_lambda':    hp.loguniform('reg_lambda', np.log(1e-3), np.log(10)),
        'reg_alpha':     hp.loguniform('reg_alpha', np.log(1e-3), np.log(10)),
    }

    def objective(params):

        # Convert parameters from floats (150.0) to integer (150) where appropriate.

        params['n_estimators'] = int(params['n_estimators'])
        params['max_depth']    = int(params['max_depth'])

        #Apply selected values
        model = xgb.XGBRegressor(
            n_estimators=params['n_estimators'],
            max_depth=params['max_depth'],
            learning_rate=params['learning_rate'],
            subsample=params['subsample'],
            colsample_bytree=params['colsample_bytree'],
            reg_lambda=params['reg_lambda'],
            reg_alpha=params['reg_alpha'],
            random_state=random_state
        )

        # Use 3-fold cross-validation.
        kf = KFold(n_splits=3, shuffle=True, random_state=random_state)
        scores = cross_val_score(model, X, y, scoring='neg_mean_squared_error', cv=kf)
        avg_mse = -np.mean(scores)
        return {'loss': avg_mse, 'status': STATUS_OK}

    trials = Trials()
    best = fmin(
        fn=objective,
        space=space,
        algo=tpe.suggest,
        max_evals=max_evals,
        trials=trials,
        rstate=np.random.default_rng(random_state),
    )

    best_params = {
        'n_estimators':  int(best['n_estimators']),
        'max_depth':     int(best['max_depth']),
        'learning_rate': best['learning_rate'],
        'subsample':     best['subsample'],
        'colsample_bytree': best['colsample_bytree'],
        'reg_lambda':    best['reg_lambda'],
        'reg_alpha':     best['reg_alpha'],
    }

    return best_params

def main():
    # Load training data from your specific CSV.
    X_train, y_train = load_training_data()

    print("Starting Bayesian hyperparameter optimization using train_meduim.csv...")
    best_params = bayes_opt_xgb(X_train, y_train, max_evals=30)

    print("\nBest hyperparameters found:")
    for k, v in best_params.items():
        print(f"  {k}: {v}")

    # (Optional) Train a final model using the best hyperparameters.
    final_model = xgb.XGBRegressor(**best_params, random_state=42)
    final_model.fit(X_train, y_train)
    preds = final_model.predict(X_train)
    mse = mean_squared_error(y_train, preds)
    print(f"\nFinal model MSE on training data: {mse:.4f}")

if __name__ == "__main__":
    main()
