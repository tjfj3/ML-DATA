#!/usr/bin/env python3
"""
Make FOUR plots from per-repeat logs (repeats_mse.csv) for GBRT runs:

1) Mean MSE vs #features (LIME · SHAP · PERM)  [linear Y]
2) Std dev of MSE across repeats vs #features  [linear Y]
3) Mean MSE vs #features                        [symlog Y]
4) Std dev of MSE across repeats                [symlog Y]

Each repeats_mse.csv must have one row per repeat. If headers exist,
they should include 'n_features' and 'mse'. Without headers the first
four columns are assumed to be [iter, n_features, seed, mse].
"""

from pathlib import Path
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

# ─────────────────────────────────────────────────────────────
# EDIT THESE PATHS (GBRT outputs)
REPEATS_CSV: Dict[str, str] = {
    "LIME": "LIME_feature_elim_out_pass1/repeats_mse.csv",
    "SHAP": "SHAP_feature_elim_out_pass1/repeats_mse.csv",
    "PERM": "pi_feature_elim_out_pass1/repeats_mse.csv",
}

OUTPUT_MEAN_LIN = Path("GBRT_mean_MSE_vs_features.png")
OUTPUT_STD_LIN  = Path("GBRT_std_MSE_vs_features.png")
OUTPUT_MEAN_LOG = Path("GBRT_mean_MSE_vs_features_log.png")
OUTPUT_STD_LOG  = Path("GBRT_std_MSE_vs_features_log.png")

TITLE_MEAN_LIN = "Average MSE vs Features for the XGBoost Model"
TITLE_STD_LIN  = "MSE variation vs Features for the XGBoost Model"
TITLE_MEAN_LOG = "Log of Average MSE vs Features for the XGBoost Model"
TITLE_STD_LOG  = "Log of MSE variation vs Features for the XGBoost Model"

INVERT_X         = False          # show many→few features left→right
SYMLOG_LINTHRESH = 1e-6
SYMLOG_BASE      = 10
# ─────────────────────────────────────────────────────────────

def _read_repeats_csv(path: Path) -> pd.DataFrame:
    """Return DataFrame with columns: n_features, mse (one row per repeat)."""
    df = pd.read_csv(path)
    cols = [c.lower() for c in df.columns]

    if "n_features" in cols and "mse" in cols:
        nf  = pd.to_numeric(df[df.columns[cols.index("n_features")]], errors="coerce")
        mse = pd.to_numeric(df[df.columns[cols.index("mse")]],         errors="coerce")
        out = pd.DataFrame({"n_features": nf, "mse": mse})
        return out.dropna(subset=["n_features", "mse"])

    # Fallback: assume [iter, n_features, seed, mse]
    if df.shape[1] < 4:
        raise ValueError(f"{path} has < 4 columns and no recognizable headers.")
    nf  = pd.to_numeric(df.iloc[:, 1], errors="coerce")
    mse = pd.to_numeric(df.iloc[:, 3], errors="coerce")
    out = pd.DataFrame({"n_features": nf, "mse": mse})
    return out.dropna(subset=["n_features", "mse"])

def _summarise(df_repeats: pd.DataFrame) -> pd.DataFrame:
    """Group per-repeat rows by n_features → mean & std of MSE."""
    g = df_repeats.groupby("n_features")["mse"]
    out = pd.DataFrame({
        "n_features": g.mean().index.astype(float),
        "mse_mean":   g.mean().values,
        "mse_std":    g.std(ddof=1).values,
    }).sort_values("n_features")
    return out

def _plot_lines(series: List[Tuple[str, pd.DataFrame]], *,
                y_col: str, title: str, out_path: Path, symlog: bool):
    fig, ax = plt.subplots(figsize=(10, 6))

    for label, df in series:
        if y_col == "mse_std":
            mask = np.isfinite(df["mse_std"])
            ax.plot(df.loc[mask, "n_features"], df.loc[mask, "mse_std"],
                    marker="o", linewidth=1.8, label=label)
        else:
            ax.plot(df["n_features"], df["mse_mean"],
                    marker="o", linewidth=1.8, label=label)

    if INVERT_X:
        ax.invert_xaxis()

    # ----- scales & tick locators -----
    if symlog:
        ax.set_yscale("symlog", base=SYMLOG_BASE,
                      linthresh=SYMLOG_LINTHRESH, linscale=1.0)
        # majors at powers of base; minors at 2–9 within each decade
        ax.yaxis.set_major_locator(mtick.LogLocator(base=SYMLOG_BASE))
        ax.yaxis.set_minor_locator(mtick.LogLocator(
            base=SYMLOG_BASE, subs=np.arange(2, 10) * 0.1))
        ax.yaxis.set_minor_formatter(mtick.NullFormatter())  # keep labels clean
    else:
        ax.yaxis.set_minor_locator(mtick.AutoMinorLocator(n=2))

    # denser x grid too (adjust steps if you like)
    ax.xaxis.set_major_locator(mtick.MultipleLocator(5))
    ax.xaxis.set_minor_locator(mtick.MultipleLocator(1))

    ax.set_xlabel("Number of features")
    ax.set_ylabel("Average MSE" if y_col == "mse_mean" else "Standard deviation of MSE")
    ax.set_title(title)

    # ----- grid behind data -----
    ax.set_axisbelow(True)
    ax.grid(True, which="major", axis="both", linestyle="--", linewidth=1.1, alpha=0.85)
    ax.grid(True, which="minor", axis="both", linestyle=":",  linewidth=0.8, alpha=0.55)

    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def main():
    series: List[Tuple[str, pd.DataFrame]] = []
    for label, p in REPEATS_CSV.items():
        path = Path(p)
        if not path.exists():
            continue
        df_rep = _read_repeats_csv(path)
        df_sum = _summarise(df_rep)
        series.append((label, df_sum))
    if not series:
        return

    _plot_lines(series, y_col="mse_mean", title=TITLE_MEAN_LIN,
                out_path=OUTPUT_MEAN_LIN, symlog=False)
    _plot_lines(series, y_col="mse_std",  title=TITLE_STD_LIN,
                out_path=OUTPUT_STD_LIN,  symlog=False)
    _plot_lines(series, y_col="mse_mean", title=TITLE_MEAN_LOG,
                out_path=OUTPUT_MEAN_LOG, symlog=True)
    _plot_lines(series, y_col="mse_std",  title=TITLE_STD_LOG,
                out_path=OUTPUT_STD_LOG,  symlog=True)

if __name__ == "__main__":
    main()
