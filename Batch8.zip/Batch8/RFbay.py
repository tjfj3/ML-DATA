"""
RFbayes.py  –  Bayesian hyper‑parameter search for RandomForestRegressor
------------------------------------------------------------------------
from RFbayes import bayes_opt_rf
best_params = bayes_opt_rf(X, y, max_evals=40, random_state=42)
"""

import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score, KFold
from hyperopt import fmin, tpe, hp, Trials, STATUS_OK

# ------------------------------------------------------------------ #
# Search space                                                       #
# ------------------------------------------------------------------ #
SPACE = {
    "n_estimators":   hp.quniform("n_estimators", 200, 1600, 100),  # 200–1600 step 100
    "max_depth":      hp.quniform("max_depth", 10, 80, 5),         # 10–80 step 5
    "min_samples_leaf": hp.quniform("min_samples_leaf", 1, 10, 1), # 1–10
    "max_features":   hp.choice("max_features",
                        [None, "sqrt", "log2", 0.25, 0.5, 0.75]),
}

# ------------------------------------------------------------------ #
# Main optimisation function                                         #
# ------------------------------------------------------------------ #
def bayes_opt_rf(X: pd.DataFrame,
                 y: np.ndarray,
                 *,
                 max_evals: int = 40,
                 random_state: int = 42) -> dict:
    """
    Bayesian optimisation for RandomForestRegressor.
    Returns a dict ready to pass to RandomForestRegressor(**best_params).
    """

    def objective(params):
        # cast Hyperopt floats → int where needed
        params = params.copy()
        params["n_estimators"]    = int(params["n_estimators"])
        params["max_depth"]       = int(params["max_depth"])
        params["min_samples_leaf"] = int(params["min_samples_leaf"])

        model = RandomForestRegressor(
            n_jobs=-1,
            random_state=random_state,
            **params
        )
        kf = KFold(n_splits=3, shuffle=True, random_state=random_state)
        scores = cross_val_score(model, X, y,
                                 scoring="neg_mean_squared_error",
                                 cv=kf, n_jobs=-1)
        mse = -np.mean(scores)
        return {"loss": mse, "status": STATUS_OK}

    trials = Trials()
    best = fmin(
        fn=objective,
        space=SPACE,
        algo=tpe.suggest,
        max_evals=max_evals,
        trials=trials,
        rstate=np.random.default_rng(random_state),
    )

    # Map back choice indices
    best["max_features"] = (
        [None, "sqrt", "log2", 0.25, 0.5, 0.75][best["max_features"]]
    )

    # Final cast to python types
    best_params = {
        "n_estimators":    int(best["n_estimators"]),
        "max_depth":       int(best["max_depth"]),
        "min_samples_leaf": int(best["min_samples_leaf"]),
        "max_features":    best["max_features"],
    }
    return best_params

# ------------------------------------------------------------------ #
# CLI quick test (optional)                                          #
# ------------------------------------------------------------------ #
if __name__ == "__main__":
    import argparse, time, sys
    p = argparse.ArgumentParser()
    p.add_argument("csv", help="CSV with features + XS column")
    p.add_argument("--max-evals", type=int, default=40)
    args = p.parse_args()

    df = pd.read_csv(args.csv)
    if "XS" not in df.columns:
        sys.exit("CSV must contain 'XS' column.")
    X, y = df.drop(columns=["XS"]), df["XS"].values

    t0 = time.time()
    best = bayes_opt_rf(X, y, max_evals=args.max_evals)
    print("Best hyper‑parameters:")
    for k, v in best.items():
        print(f"  {k}: {v}")
    print(f"\nTuning took {(time.time()-t0)/60:.1f} minutes")
